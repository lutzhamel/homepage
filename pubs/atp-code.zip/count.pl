% recursive counting of elements
% in a list.

% base case:
% the count of an empty list is 0
count([],0).

% recursive step:
% the count of any list List is Count if
%    List can be divided into a first element and the Rest of the list and
%    T is the count of the Rest of the list and
%    Count is T plus 1.
count(List,Count) :- 
	List=[_|Rest],
	count(Rest,T), 
	Count is T + 1.

% try it!
:- count([1,2,3],P),writeln(P).
 