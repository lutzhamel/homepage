% calc-sem.pl

:- consult('preamble.pl').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% semantic definition of a calculator language with 
% assignments and print statements
% version 1.0
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% syntax definition -- Lisp like prefix notation for expressions
%
%  E ::= X
%     |  I
%     |  mult(E,E)
%     |  plus(E,E)
%     |  minus(E,E)
%
%  S ::= assign(X,E)
%     |  print(E)
%     |  S @ S
%
%  I ::= <any integer digit>
%  X ::= <any variable name> 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% for convenience sake make '@' infix and left associative
:- op(725,yfx,@).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% semantic definition of integer expressions

L -->> L :-
	is_int(L),!.

B:: X -->> V :-
	is_var(X),
	lookup(X,B,V),!.

B:: mult(E1,E2) -->> V :-
	B:: E1 -->> V1,
	B:: E2 -->> V2,
	V xis V1 * V2,!.

B:: plus(E1,E2) -->> V :-
	B:: E1 -->> V1,
	B:: E2 -->> V2,
	V xis V1 + V2,!.

B:: minus(E1,E2) -->> V :-
	B:: E1 -->> V1,
	B:: E2 -->> V2,
	V xis V1 - V2,!.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% semantic definition of statements

B:: assign(X,E) -->> [(X,V)|B] :-
	is_var(X),
	B:: E -->> V,!.

B:: print(E) -->> B :-
	B:: E -->> V,
	write('Output value of '),
	write(E),
	write(' is '),
	writeln(V),!.

B:: S1 @ S2 -->> B2 :-
	 B:: S1 -->> B1,
	B1:: S2 -->> B2,!.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% the predicate 'lookup(+Var,+State,-Value)' finds a variable binding
% in a state and returns the corresponding value.

:- dynamic (lookup)/3.                % modifiable predicate
:- multifile (lookup)/3.

lookup(X,[(X,V)|_],V).

lookup(X,[_|Rest],V) :-
	lookup(X,Rest,V),!.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% example

:- s:: assign(x,plus(10,1)) @ print(x) -->> S, writeln(S).


