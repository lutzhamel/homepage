% proof-induction.pl
:- consult('calc-sem.pl').

:- >>> 'Proof by structural induction'.

:- >>> 'induction on expressions'.

:- >>> 'Base cases:'.

:- >>> 'Variables'.
:- >>> 'Assume that states are finite'.
:- assume lookup(x,s,vx).
:- show s:: x -->> vx.

:- >>> 'Constants'.
:- assume is_int(n).
:- show s:: n -->> n.

:- >>> 'Inductive cases'.

:- >>> 'Operators'.
:- >>> 'mult'.
:- assume s:: a -->> va.
:- assume s:: b -->> vb.
:- show s:: mult(a,b) -->> va*vb.

:- >>> 'the remaining operators'.
:- >>> 'can be proved similarly'.

:- >>> 'induction on programming constructs'.

:- >>> 'Base cases:'.

:- >>> 'assignments'.
:- assume s:: e -->> ve.
:- show s:: assign(x,e) -->> [(x,ve)|s].

:- >>> 'print'.
:- assume s:: e -->> ve.
:- show s:: print(e) -->> s.

:- >>> 'Inductive step:'.

:- >>> 'composition'.
:- assume _A:: s1 -->> v1.
:- assume _B:: s2 -->> v2.
:- show s:: s1 @ s2 -->> v2.
