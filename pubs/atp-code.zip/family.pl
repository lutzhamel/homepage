% facts
female(betty).
male(bob).
parent(betty,bob).

% rules
mother(X,Y) :- parent(X,Y),female(X).

% query
:- mother(betty,bob).
