% proof-equiv.pl

:- consult('calc-sem.pl').

:- >>> 'Show that mult(2,3) is semantically equiv to add(3,3),'.
:- >>> 'it suffices to show that'.
:- >>> '   (forall s)(exists V)'.
:- >>> '        [s:: mult(2,3)-->>V ^ s:: plus(3,3)-->>V]'.

% proof
:- show s:: mult(2,3)-->>V , s:: plus(3,3)-->>V.

