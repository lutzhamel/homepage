:- consult('functional-rec-sem.pl').

:- >>> 'By-value parameter passing'.

:- assume          (d,s):: a -->> va.
:- assume (d,[(x,va)|s]):: e(x) -->> ve.

:- show
         (d,s):: let(x,a,e(x)) -->> V1,
	 (d,s):: apply(fn(x,e(x)),a) -->> V2,
	 V1=V2.
