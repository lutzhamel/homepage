:- consult('functional-sem.pl').

:- >>> 'some simple tests for our functional language'.

:- >>> 'Simple arithmetic operations:'.
:- >>> 'show that forall s, s:: plus(1,1) -->> 2'.
:- show s:: plus(1,1) -->> 2. 

:- >>> 'show that for state [(x,2)], [(x,2)]:: mult(x,x) -->> 4'.
:- show [(x,2)]:: mult(x,x) -->> 4. 

:- >>> 'Function calls:'.
:- >>> 'Increment Function: show that for program P:'.
:- assume program
       let(inc,
	   fn(x,plus(x,1)),
	   apply(inc,y)).
:- >>> 'we have for all states [(y,1)|s], [(y,1)|s]:: P -->> 2'.
:- show 
        program P,
	[(y,1)|s]:: P -->> 2.

:- >>> 'Higher order functions: curried plus'.
:- assume program
       let(add,
	   fn(x,
	      fn(y,plus(x,y))),
	   apply(apply(add,1),1)).
:- >>> 'we have for all states s, s:: P -->> 2'.
:- show 
        program P,
	s:: P -->> 2.

:- >>> 'Higher order functions: twice'.
:- assume program
       let(inc,
           fn(x,plus(x,1)),
           let(twice,
               fn(f,
                  fn(x,
                     apply(f,apply(f,x)))),
               apply(apply(twice,inc),y))).
:- >>> 'we have for all states [(y,0)|s], [(y,0)|s]:: P -->> 2'.
:- show 
        program P,
	[(y,0)|s]:: P -->> 2.

:- >>> 'Factorial: show that for program P:'.
:- assume program
        let(fact,
            fn(x,
               if(eq(x,1),
                  1,
                  mult(x,
                       apply(fact,
		             minus(x,1))))),
            apply(fact,y)).
:- >>> 'we have for all states [(y,3)|s], [(y,3)|s]:: P -->> 6'.
:- >>> 'NOTE: this program will fail!!!'.
:- show 
        program P,
	[(y,3)|s]:: P -->> 6.

