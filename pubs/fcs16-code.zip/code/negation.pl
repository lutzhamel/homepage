:- consult('preamble.pl').

on_top(X) :- neg(blocked(X)). 
blocked(X) :- on(Y,X).
on(a,b).
