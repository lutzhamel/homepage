% functional-syn.pl
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% the syntactic definition of a small functional
% programming language
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% functional grammar
% expr
expr --> [fn],var,[=>],expr.
expr --> term,addterm.

% term
term --> factor,multfactor.

% addterm
addterm --> [+],expr.
addterm --> [-],expr.
addterm --> [].

% multfactor
multfactor --> [*],term.
multfactor --> [].

% factor
factor --> [if],bexpr,[then],expr,[else],expr,[end].
factor --> [let],var,[=],expr,[in],expr,[end].
factor --> ['('],expr,[')'],factor.
factor --> var,factor.
factor --> ['('],expr,[')'].
factor --> [I], { integer(I) }.
factor --> var.

% variables
var --> [X], { variable_name(X) }.

% bexpr
bexpr --> [true].
bexpr --> [false].
bexpr --> [not],bexpr.
bexpr --> expr,[==],expr.
bexpr --> expr,[<=],expr.

% variable name
variable_name(X) :-
    atom(X),
    X \= '(',
    X \= ')',
    X \= (not),
    X \= if,
    X \= then,
    X \= else,
    X \= end,
    X \= let,
    X \= in.

% test cases
:- Input = [10,+,2,*,3], phrase(expr,Input).
:- phrase(expr,[x,1]).
:- phrase(expr,['(',fn,x,=>,x,')',1]).
:- phrase(expr,['(',fn,x,=>,x,')','(',fn,x,=>,x,')',1]).
:- phrase(expr,[if,not,1,==,2,then,3,else,4,end]).
:- phrase(expr,[let,x,=,fn,y,=>,y,in,x,1,end]).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% functional grammar with synthesized attributes representing the
% abstract syntax tree.

% expr
expr(fn(X,E))      --> [fn],
                       var(X),
                       [=>],
                       expr(E).
expr(plus(T1,T2))  --> term(T1), 
                       addterm([+],T2).
expr(minus(T1,T2)) --> term(T1), 
                       addterm([-],T2).
expr(T)            --> term(T),
                       addterm([],[]).

% term
term(mult(F1,F2)) --> factor(F1), 
                      multfactor([*],F2).
term(F)           --> factor(F), 
                      multfactor([],[]).

% addterm
addterm([+],E)  --> [+], 
                    expr(E).
addterm([-],E)  --> [-],  
                    expr(E).
addterm([],[])  --> [].


% multfactor
multfactor([*],T) --> [*], 
                      term(T).
multfactor([],[]) --> [].


% factor
factor(if(B,E1,E2))  --> [if],
                         bexpr(B),
                         [then],
                         expr(E1),
                         [else],
                         expr(E2),
                         [end].
factor(let(X,E1,E2)) --> [let],
                         var(X),
                         [=],
                         expr(E1),
                         [in],
                         expr(E2),
                         [end].
factor(apply(E1,E2)) --> ['('],
                         expr(E1),
                         [')'],
                         factor(E2).
factor(apply(X,E2))  --> var(X),
                         factor(E2).
factor(Expr)         --> ['('],
                         expr(Expr),
                         [')'].
factor(I)            --> [I], { integer(I) }.
factor(X)            --> var(X).

% variables
var(X) --> [X], { variable_name(X) }.

% bexpr
bexpr(true)      --> [true].
bexpr(false)     --> [false].
bexpr(not(E))    --> [not],
                     bexpr(E).
bexpr(eq(E1,E2)) --> expr(E1),
                     [==],
                     expr(E2).
bexpr(le(E1,E2)) --> expr(E1),
                     [<=],
                     expr(E2).




% test cases
:- Input = [10,+,2,*,3], phrase(expr(Tree),Input), writeln(Tree).
:- phrase(expr(T),[x,1]), writeln(T).
:- phrase(expr(T),['(',fn,x,=>,x,')',1]), writeln(T).
:- phrase(expr(T),['(',fn,x,=>,x,')','(',fn,x,=>,x,')',1]), writeln(T).
:- phrase(expr(T),[if,not,1,==,2,then,3,else,4,end]), writeln(T).
:- phrase(expr(T),[let,x,=,fn,y,=>,y,in,x,1,end]),writeln(T).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% tokenizer
% a simple tokenizer that tokenizes the input string into
% a list of atoms as expected by the parser generated from 
% the DCG

tokenizer(Instring,Outlist) :-
        tokenize_atom(Instring,Tlist),
        check_twocharops(Tlist,Outlist).

% check for two character operators
check_twocharops([],[]).

check_twocharops([A],[A]).

check_twocharops([A,B|Rest],[Newop|Newlist]) :-
        atom_concat(A,B,Newop),
        member(Newop,[(<=),(==),(=>)]),
        check_twocharops(Rest,Newlist).

check_twocharops([A|Rest],[A|Newlist]) :-
        check_twocharops(Rest,Newlist).




