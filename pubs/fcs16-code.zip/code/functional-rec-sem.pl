:- consult('preamble.pl').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% semantic definition of a small functional language with 
% recursive function definitions.
% version 1.0
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% abstract syntax definition [concrete syntax]
%
%  E ::= X
%     |  I
%     |  mult(E,E)           [E * E]
%     |  plus(E,E)           [E + E]
%     |  minus(E,E)          [E - E]
%     |  if(B,E,E)           [if B then E else E end]
%     |  let(X,E,E)          [let X = E in E end]
%     |  letrec(F,X,E,E)     [let rec F X => E in E end]
%     |  fn(X,E)             [fn X => E]
%     |  apply(E,E)          [E E]
%
%  B ::= true 
%     |  false
%     |  le(E,E)             [E <= E]
%     |  eq(E,E)             [E == E]
%     |  not(E)              [not E]
%
%  I ::= <any integer digit>
%  X ::= <any variable name> 
%  F ::= <any function name> 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% semantic definition of integer expressions

I -->> I :-
	is_int(I),!.

% see if the name is a rec function
(D,_):: F -->> [[X,E,S]] :-
	is_var(F),
	lookup(F,D,[[X,E,S]]),!.

% else it is a regular variable
(_,S):: X -->> V :-
	is_var(X),
	lookup(X,S,V),!.

(D,S):: mult(E1,E2) -->> V :-
	(D,S):: E1 -->> V1,
	(D,S):: E2 -->> V2,
	V xis V1 * V2,!.

(D,S):: plus(E1,E2) -->> V :-
	(D,S):: E1 -->> V1,
	(D,S):: E2 -->> V2,
	V xis V1 + V2,!.

(D,S):: minus(E1,E2) -->> V :-
	(D,S):: E1 -->> V1,
	(D,S):: E2 -->> V2,
	V xis V1 - V2,!.

(D,S):: if(B,E,_) -->> V :-
	(D,S):: B -->> true,
	(D,S):: E -->> V,!.

(D,S):: if(B,_,E) -->> V :-
	(D,S):: B -->> false,
	(D,S):: E -->> V,!.

(D,S):: let(X,E1,E2) -->> V :-
  	         is_var(X),
	         neg(peek(X,D)),
	         (D,S):: E1 -->> V1,
	(D,[(X,V1)|S]):: E2  -->> V,!.

(D,S):: letrec(F,X,E1,E2) -->> V :-
  	         is_var(F),
  	         is_var(X),
	         neg(peek(F,D)),
	         neg(peek(F,S)),
	([(F,[[X,E1,S]])|D],S):: E2  -->> V,!.

(_,S):: fn(X,E) -->> [[X,E,S]] :- 
	is_var(X),!. 

(D,S):: apply(E1,E2) -->> V :-
                        (D,S):: E1 -->> [[X,E,Sfn]],
                        (D,S):: E2 -->> V2,
	     (D,[(X,V2)|Sfn]):: E -->> V,!. 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% semantic definition of boolean expressions

B -->> B :- 
	is_bool(B),!.

(D,S):: le(E1,E2) -->> B :-
	(D,S):: E1 -->> V1,
	(D,S):: E2 -->> V2,
	B xis V1 =< V2,!.

(D,S):: eq(E1,E2) -->> B :-
	(D,S):: E1 -->> V1,
	(D,S):: E2 -->> V2,
	B xis V1 == V2,!.

(D,S):: not(B1) -->> B2 :-
	(D,S):: B1 -->> V1,
	B2 xis not(V1),!.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% the predicate 'lookup(+Var,+Env,-Value)' finds a variable binding
% in a binding environment and returns the corresponding value.

:- dynamic (lookup)/3.                % modifiable predicate
:- multifile (lookup)/3.

lookup(X,[(X,V)|_],V).

lookup(X,[_|Rest],V) :-
	lookup(X,Rest,V).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% the predicate 'peek(+Var,+Env)' finds a variable binding
% in a binding environment.

:- dynamic (peek)/2.                % modifiable predicate
:- multifile (peek)/2.

peek(X,[(X,_)|_]).

peek(X,[_|Rest]) :-
	peek(X,Rest).



