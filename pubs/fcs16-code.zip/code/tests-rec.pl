:- consult('functional-rec-sem.pl').

:- >>> 'some simple tests for our functional language with recursive functions defs'.

:- >>> 'Simple arithmetic operations:'.
:- >>> 'show that forall s, s:: plus(1,1) -->> 2'.
:- show (d,s):: plus(1,1) -->> 2. 

:- >>> 'show that for state (d,[(x,2)]), (d,[(x,2)]):: mult(x,x) -->> 4'.
:- show (d,[(x,2)]):: mult(x,x) -->> 4. 

:- >>> 'Function calls:'.
:- >>> 'Increment Function: show that for program P:'.
:- assume program
       let(inc,
	   fn(x,plus(x,1)),
	   apply(inc,1)).
:- >>> 'we have for all states (d,s), (d,s):: P -->> 2'.
:- show 
        program P,
	(d,s):: P -->> 2.

:- >>> 'Higher order functions: curried plus'.
:- assume program
       let(add,
	   fn(x,
	      fn(y,plus(x,y))),
	   apply(apply(add,1),1)).
:- >>> 'we have for all states (d,s), (d,s):: P -->> 2'.
:- show 
        program P,
	(d,s):: P -->> 2.

:- >>> 'Higher order functions: twice'.
:- assume program
       let(inc,
	   fn(x,plus(x,1)),
           let(twice,
               fn(f,
                  fn(x,
                     apply(f,apply(f,x)))),
               apply(apply(twice,inc),0))).
:- >>> 'we have for all states (d,s), (d,s):: P -->> 2'.
:- show 
        program P,
	(d,s):: P -->> 2.

:- >>> 'Factorial: show that for program P:'.
:- assume program
        letrec(fact,
               x,
               if(eq(x,1),
                  1,
                  mult(x,
                       apply(fact,
		             minus(x,1)))),
               apply(fact,3)).
:- >>> 'we have for all states (d,s), (d,s):: P -->> 6'.
:- show 
        program P,
	(d,s):: P -->> 6.

