:- consult('functional-rec-sem.pl').

:- >>> 'Proof by structural induction'.

:- >>> 'Base cases:'.

:- >>> 'Variables'.
:- >>> 'Assume that states are finite'.
:- assume lookup(x,s,vx).
:- show (d,s):: x -->> vx.
:- remove lookup(x,s,vx).

:- >>> 'Constants'.
:- assume is_int(n).
:- show (d,s):: n -->> n.
:- remove is_int(n).

:- >>> 'anonymous function definitions'.
:- assume is_var(x).
:- show (d,s):: fn(x,e) -->> [[x,e,s]].
:- remove is_var(x).

:- >>> 'Inductive cases'.

:- >>> 'Operators'.
:- >>> 'mult'.
:- assume (d,s):: a -->> va.
:- assume (d,s):: b -->> vb.
:- show (d,s):: mult(a,b) -->> va*vb.
:- remove (d,s):: a -->> va.
:- remove (d,s):: b -->> vb.

:- >>> 'the remaining operators and boolean'.
:- >>> 'expressions can be proved similarly'.

:- >>> 'programming constructs'.
:- >>> 'let-expression'.
:- assume (d,s):: a -->> va.
:- assume (d,[(x,va)|s]):: e(x) -->> ve.
:- show (d,s):: let(x,a,e(x)) -->> ve.
:- remove (d,s):: a -->> va.
:- remove (d,[(x,va)|s]):: e(x) -->> ve.

:- >>> 'if-expression with case analysis'.
:- assume (d,s):: e1 -->> v1.
:- assume (d,s):: e2 -->> v2.

:- assume (d,s):: b -->> true.
:- show (d,s):: if(b,e1,e2) -->> v1.
:- remove (d,s):: b -->> true.

:- assume (d,s):: b -->> false.
:- show (d,s):: if(b,e1,e2) -->> v2.
:- remove (d,s):: b -->> false.

:- remove (d,s):: e1 -->> v1.
:- remove (d,s):: e2 -->> v2.

