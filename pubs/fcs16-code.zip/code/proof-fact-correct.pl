:- consult('functional-rec-sem.pl').

:- >>> 'Factorial: show that program P:'.
:- assume program
        letrec(fact,
               x,
               if(eq(x,1),
                  1,
                  mult(x,
                       apply(fact,
		             minus(x,1)))),
               apply(fact,i)).
:- >>> 'is correct for all inputs i > 0'.

:- >>> 'proof by induction on i'.
:- >>> 'base case: i=1'.
:- assume i -->> 1. 
:- show 
        program P,
	(d,s):: P -->> 1.

:- >>> 'inductive step: i=n'.
:- assume i -->> n.
:- assume false xis n==1.
:- >>> 'inductive hypothesis:'.
:- assume apply(fact,minus(x,1)) -->> factorial(n-1).
:- show 
        program P,
	(d,s):: P -->> n*factorial(n-1).
