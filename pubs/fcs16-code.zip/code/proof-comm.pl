:- consult('functional-rec-sem.pl').

:- >>> 'Assume that we have expressions a and b'. 
:- assume (d,s):: a -->> va.
:- assume (d,s):: b -->> vb.

:- >>> 'Integer multiplication is commutative'. 
:- assume equiv(A*B,B*A).

:- show
     (d,s):: mult(a,b) -->> V1,
     (d,s):: mult(b,a) -->> V2, 
     equiv(V1,V2).
