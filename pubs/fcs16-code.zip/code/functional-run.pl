%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% prompter
% a simple interactive shell for our functional programming language

:- consult('functional-sem.pl').
:- consult('functional-syn.pl').

prompter :- 
	%write('> '),  % can't do this because of a bug in read_line_to_codes: paren matching
	read_line_to_codes(user_input,Cs), 
        check_quit(Cs),
	atom_codes(Inputstring, Cs), 
	tokenizer(Inputstring,Atomlist),
	%writeln(['atomlist: ',Atomlist]),
	phrase(expr(Tree),Atomlist),
	writeln(['AST: ',Tree]),
	s0:: Tree -->> Value,
	write('>> '),
	write(Value),
	nl,
	!,
	prompter.

prompter :-
	writeln('Error!'),
	prompter.


% see if Cntrl-D was pressed to quit the shell
check_quit(S) :-
	S = end_of_file,
	writeln('Bye!'), 
	halt.

check_quit(_).


% run it
:- writeln('Enter a functional expression:').
:- prompter.

%let inc = fn x => x + 1 in let twice = fn f => fn y => f f y in (twice inc) 0 end end

