:- consult('functional-rec-sem.pl').

:- >>> 'Increment Function: show that for program P:'.
:- assume program
       let(inc,
           fn(x,plus(x,1)),
           apply(inc,1)).
:- >>> 'we have for all states (d,s), (d,s):: P -->> 2'.
:- show
        program P,
        (d,s):: P -->> 2.

