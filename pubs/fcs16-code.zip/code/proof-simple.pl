:- consult('preamble.pl').
:- >>> 'assume the commutative property'. 
:- >>> 'of integer addition'.
:- assume equiv(A+B,B+A).

:- >>> 'show that expressions X and Y'.
:- >>> 'are related by commutativity'.
:- show 
     X xis a + b, 
     Y xis b + a, 
     equiv(X,Y).
