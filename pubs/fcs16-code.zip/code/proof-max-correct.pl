:- consult('functional-rec-sem.pl').

:- >>> 'show that program'.
:- >>> ' P = "let(z,if(le(n,m),m,n),z)"'.
:- >>> 'computes the maximum of'.
:- >>> 'the values assigned to m and n'.

:- assume program let(z,if(le(n,m),m,n),z).

:- >>> 'assume values for m and n'.
:- assume (d,s):: m -->> vm.
:- assume (d,s):: n -->> vn.
                                                                                                   
:- >>> 'case analysis on values vm and vn'.                                                       
:- >>> 'case vm = max(vm,vn)'.                                                                       
:- assume vm xis max(vm,vn).
:- >>> 'this implies that'.
:- assume true xis (vn =< vm).
:- show 
      program P,  
      (d,s):: P -->> vm.

:- remove vm xis max(vm,vn).
:- remove true xis (vn =< vm).

:- >>> 'case vn = max(vm,vn)'.
:- assume vn xis max(vm,vn).
:- >>> 'this implies that'.
:- assume false xis (vn =< vm).
:- show
      program P, 
      (d,s):: P -->> vn.

:- remove vn xis max(vm,vn).
:- remove false xis (vn =< vm).

