:- consult('functional-sem.pl').

:- >>> 'Higher order functions: twice'.
:- assume program
       let(inc,
           fn(x,plus(x,1)),
           let(twice,
               fn(f,
                  fn(x,
                     apply(f,apply(f,x)))),
               apply(apply(twice,inc),0))).
:- >>> 'we have for all states s, s:: P -->> 2'.
:- show
        program P,
        (d,s):: P -->> 2.
