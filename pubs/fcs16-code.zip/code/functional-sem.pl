% functional-sem.pl

:- consult('preamble.pl').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% semantic definition of a small functional language with 
% only anonymous function definitions
% version 1.0
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% abstract syntax definition [concrete syntax]
%
%  E ::= X
%     |  I
%     |  mult(E,E)           [E * E]
%     |  plus(E,E)           [E + E]
%     |  minus(E,E)          [E - E]
%     |  if(B,E,E)           [if B then E else E end]
%     |  let(X,E,E)          [let X = E in E end]
%     |  fn(X,E)             [fn X => E]
%     |  apply(E,E)          [E E]
%
%  B ::= true 
%     |  false
%     |  le(E,E)             [E <= E]
%     |  eq(E,E)             [E == E]
%     |  not(E)              [not E]
%
%  I ::= <any integer digit>
%  X ::= <any variable name> 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% semantic definition of integer expressions

I -->> I :-
	is_int(I),!.

S:: X -->> V :-
	is_var(X),
	lookup(X,S,V),!.

S:: mult(E1,E2) -->> V :-
	S:: E1 -->> V1,
	S:: E2 -->> V2,
	V xis V1 * V2,!.

S:: plus(E1,E2) -->> V :-
	S:: E1 -->> V1,
	S:: E2 -->> V2,
	V xis V1 + V2,!.

S:: minus(E1,E2) -->> V :-
	S:: E1 -->> V1,
	S:: E2 -->> V2,
	V xis V1 - V2,!.

S:: if(B,E,_) -->> V :-
	S:: B -->> true,
	S:: E -->> V,!.

S:: if(B,_,E) -->> V :-
	S:: B -->> false,
	S:: E -->> V,!.

S:: let(X,E1,E2) -->> V :-
 	         is_var(X),
	         S:: E1 -->> V1,
	[(X,V1)|S]:: E2  -->> V,!.

S:: fn(X,E) -->> [[X,E,S]] :- 
	is_var(X),!. 

S:: apply(E1,E2) -->> V :-
                S:: E1 -->> [[X,E,Sfn]],
                S:: E2 -->> V2,
       [(X,V2)|Sfn]:: E -->> V,!. 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% semantic definition of boolean expressions

B -->> B :- 
	is_bool(B),!.

S:: le(E1,E2) -->> B :-
	S:: E1 -->> V1,
	S:: E2 -->> V2,
	B xis V1 =< V2,!.

S:: eq(E1,E2) -->> B :-
	S:: E1 -->> V1,
	S:: E2 -->> V2,
	B xis V1 == V2,!.

S:: not(B1) -->> B2 :-
	S:: B1 -->> V1,
	B2 xis not(V1),!.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% the predicate 'lookup(+Var,+State,-Value)' finds a variable binding
% in a state and returns the corresponding value.

:- dynamic (lookup)/3.                % modifiable predicate
:- multifile (lookup)/3.

lookup(X,[(X,V)|_],V).

lookup(X,[_|Rest],V) :-
	lookup(X,Rest,V),!.



