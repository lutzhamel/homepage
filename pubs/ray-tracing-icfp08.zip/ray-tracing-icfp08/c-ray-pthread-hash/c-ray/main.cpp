#include <iostream>
#include <fstream>

#include "ray_trace.h"

#include "ray_geom.h"
#include "entity_file.h"
#include "math_util.h"
#include "gen_util.h"
#include "ssp_util.h"
#include <algorithm>
#include <pthread.h>
#include <stdlib.h>
#include <sys/time.h>
#include <math.h>

using namespace std;

//==============================================================================

void print_usage() {
   cerr << "Usage: c-ray  <ssp-filename> <num-worker-threads> <de1 (deg)> <de2 (deg)> <num-rays> <start-depth> <max-range> <max-bounces>\n"
        << endl;
}

//==============================================================================

/**
 If successful, returns true and sets the output parameters accordingly.
 Otherwise returns false.
 */
bool parse_cmdline(int argc, const char* argv[],
      string & ssp_filename, 
      int & num_worker_threads,
      float & de1_deg,
      float & de2_deg,
      int & num_rays,
      float & start_depth,
      float & max_range,
      int & max_bounces)
 {
   if (argc != 9) {
      return false;
   }

   string_to_type(argv[1], ssp_filename);

   if (! string_to_type(argv[2], num_worker_threads)) {
      cerr << "Couldn't parse <num-worker-threads> as an int." << endl;
      return false;
   }

   if (! string_to_type(argv[3], de1_deg)) {
      cerr << "Couldn't parse <de1 (deg)> as a float." << endl;
      return false;
   }

   if (! string_to_type(argv[4], de2_deg)) {
      cerr << "Couldn't parse <de2 (deg)> as a float." << endl;
      return false;
   }

   if (! string_to_type(argv[5], num_rays)) {
      cerr << "Couldn't parse <num-rays> as an int." << endl;
      return false;
   }

   if (! string_to_type(argv[6], start_depth)) {
      cerr << "Couldn't parse <start-depth> as a float." << endl;
      return false;
   }

   if (! string_to_type(argv[7], max_range)) {
      cerr << "Couldn't parse <max-range> as a float." << endl;
      return false;
   }

   if (! string_to_type(argv[8], max_bounces)) {
      cerr << "Couldn't parse <max_bounces> as an int." << endl;
      return false;
   }

   return true;
}

//==============================================================================

struct Host_Pthread_Params {
   vector<DepthBandInfo> * p_dbands;
   float start_z;
   float max_range;
   int max_bounces;
   float de_rad_low;
   float de_rad_high;
   float delta_de_rad;
};

//==============================================================================

void host_pthread_func(const Host_Pthread_Params * pParams) {
//    cout << pthread_self() << " started! de_rad_low = " << pParams->de_rad_low << endl;
//    cout << "I started!: "
//       << "de1: " << pParams->de1 << endl
//       << "de2: " << pParams->de2 << endl
//       << "delta_de_rad: " << pParams->delta_de_rad << endl
//       << endl;
   const vector<DepthBandInfo> & dbands = *(pParams->p_dbands);
// int n = 0;

   for ( float de = pParams->de_rad_low; 
         de <= pParams->de_rad_high; 
         de += pParams->delta_de_rad) {
// ++n;
      vector<RayStatus> trace = trace_one_ray(
         *(pParams->p_dbands), 0, pParams->start_z, de, 
         pParams->max_range, pParams->max_bounces);
   }

//    cout << "I finished! n=" << n << endl;
  pthread_exit(NULL);
}

//==============================================================================

int main(int argc, const char* argv[]) {
   // Parse the command line...
   string ssp_filename;
   int num_worker_threads;
   float de1_deg;
   float de2_deg;
   int num_rays;
   float start_depth;
   float max_range;
   int max_bounces;

   if (! parse_cmdline(argc, argv, ssp_filename, 
         num_worker_threads, de1_deg, de2_deg, num_rays, start_depth, 
         max_range, max_bounces)) {
      cerr << endl;
      print_usage();
      return 1;
   }

   // Load in the SSP...
   ifstream ssp_stream(ssp_filename.c_str(), ifstream::in);
   if (ssp_stream.fail()) {
      cerr << "Unable to open the SSP file '" << ssp_filename << "'" << endl;
      return 1;
   }

   vector<DepthBandInfo> dbands = load_ssp(ssp_stream);


   // Get on with the processing...
   float z_at_surface = dbands[0].z_shallow;
   float start_z = z_at_surface - start_depth;

   // Process the rays...
   vector<pthread_t> threads;
   float de1_rad = de1_deg * (M_PI / 180.0);
   float de2_rad = de2_deg * (M_PI / 180.0);
   float de_rad_low = min(de1_rad, de2_rad);
   float de_rad_high = max(de1_rad, de2_rad);

   float delta_de_rad = num_worker_threads * (de_rad_high - de_rad_low) / (num_rays - 1);

   struct timeval tv1, tv2;
   gettimeofday(& tv1, NULL);

   for (int i = 0; i < num_worker_threads; ++i) {
      Host_Pthread_Params * pParams = new Host_Pthread_Params;
      pParams->p_dbands = & dbands;
      pParams->de_rad_low = de_rad_low + (i * delta_de_rad);
      pParams->de_rad_high = de_rad_high;
      pParams->delta_de_rad = delta_de_rad;
      pParams->start_z = start_z;
      pParams->max_range = max_range;
      pParams->max_bounces = max_bounces;

      pthread_t thread_id;

      typedef void * (*Pthread_Func_Ptr)(void*);

      if (pthread_create(& thread_id, NULL, reinterpret_cast<Pthread_Func_Ptr>(host_pthread_func), pParams)) {
         cerr << "Failed to create thread." << endl;
         return 1;
      }

      threads.push_back(thread_id);
   }

   for (int i = 0; i < threads.size(); ++i) {
      pthread_join(threads.at(i), NULL);
   }

   gettimeofday(& tv2, NULL);

   float elapsed_seconds = (tv2.tv_sec - tv1.tv_sec) + (tv2.tv_usec - tv1.tv_usec)/1000000.0;
//    cout << "Elapsed seconds: " << elapsed_seconds << endl;
   cout << elapsed_seconds << endl;
}
