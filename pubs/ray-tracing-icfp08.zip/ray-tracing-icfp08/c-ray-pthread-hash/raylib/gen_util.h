#ifndef _GEN_UTIL_H
#define _GEN_UTIL_H

#include <iostream>
#include <sstream>
#include <vector>
#include <string>
#include "ExceptionWithString.h"

/**
Reads in all lines of text from the specified stream.  Throws an exception if
anything goes wrong.
*/
std::vector<std::string> readlines(std::istream & is, int line_buffer_size = 1000)
   throw (ExceptionWithString);

/**
Returns a string that is like 's' but has no leading or trailing whitespace.
(Whitespace = ' ', '\n', '\r', and '\t'.)
 */
std::string strip(const std::string & s);

/**
Returns the sequence of substrings that are separated by the character
'c'.  'c' does not appear in the substrings.
*/
std::vector<std::string> split(const std::string & s, const char c);

/**
 Relies on streams' ability to cast their content to valuse of type 'T'.
 Returns 'true' if the conversion is successful, 'false' if not.
 */
template<typename T>
bool string_to_type(const std::string & s, T & t )
   throw (ExceptionWithString)
{
    std::istringstream is(s);
    is >> t;

    return (! is.fail());
}


/**
 Relies on streams' ability to cast their content to valuse of type 'T'.
 Returns 'true' if the conversion is successful, 'false' if not.
 */
template<typename T>
bool string_to_type(const char * p, T & t )
   throw (ExceptionWithString)
{
    std::string s(p);
    std::istringstream is(s);
    is >> t;

    return (! is.fail());
}

#endif
