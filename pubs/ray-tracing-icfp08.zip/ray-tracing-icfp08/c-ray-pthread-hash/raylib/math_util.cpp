#include "math_util.h"

#include <math.h>

const float rad2deg = 180.0 / M_PI;

const float deg2rad = M_PI / 180.0;

bool is_near(float x, float y, float epsilon) {
   return fabs(x - y) < fabs(epsilon);
}
