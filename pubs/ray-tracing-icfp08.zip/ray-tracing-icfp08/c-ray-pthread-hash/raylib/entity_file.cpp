#include "entity_file.h"

#include <string>
#include <math.h>
#include "math_util.h"

using namespace std;

static const string default_entity_color = "1.0 1.0 1.0 1.0";

//==============================================================================

void graph_point(std::ostream & os, float x, float y) {
   os << "point 0 " 
      << x << " " << y << " 0 "
      << "0 0 0 " 
      << default_entity_color << endl;
}

//==============================================================================

void graph_line_segment(std::ostream & os, 
      float x1,  float y1,  float x2,  float y2) {
   os << "line 0 " 
      << x1 << " " << y1 << " 0 "
      << x2 << " " << y2 << " 0 "
      << default_entity_color << endl;
}

//==============================================================================

void graph_circle(std::ostream & os, 
      float center_x, float center_y, float radius) {
   os << "circle "
      << radius << " " << center_x << " " << center_y << " 0 "
      << "0 0 0 "
      << default_entity_color << endl;
}

//==============================================================================

void graph_arc1(std::ostream & os, float center_x, float center_y, float radius,
      float x1,  float y1,  float x2,  float y2) {

   float delta_x1 = center_x - x1;
   float delta_y1 = center_y - y1;
   float angle_start = rad2deg * atan2f(delta_y1, delta_x1);

   float delta_x2 = center_x - x2;
   float delta_y2 = center_y - y2;
   float angle_end = rad2deg * atan2f(delta_y2, delta_x2);

   os << "arc " 
      << radius << " " << center_x << " " << center_y << " 0 "
      << angle_end << " " << angle_start << " 0 "
      << default_entity_color << endl;
}

//==============================================================================
