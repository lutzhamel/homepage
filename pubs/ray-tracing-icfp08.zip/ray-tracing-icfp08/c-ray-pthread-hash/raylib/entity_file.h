#ifndef _ENTITY_FILE_H
#define _ENTITY_FILE_H

#include<iostream>

void graph_point(std::ostream & os, float x, float y);

void graph_line_segment(std::ostream & os, 
   float x1,  float y1,  float x2,  float y2);

void graph_circle(std::ostream & os, 
   float center_x, float center_y, float radius);

void graph_arc1(std::ostream & os, float center_x, float center_y, float radius,
    float x1,  float y1,  float x2,  float y2);


#endif
