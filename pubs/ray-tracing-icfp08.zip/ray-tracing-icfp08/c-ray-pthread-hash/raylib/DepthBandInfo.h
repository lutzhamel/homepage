#ifndef _DEPTHBANDINFO_H
#define _DEPTHBANDINFO_H

#include <string>

/**
 Describes a single depth band in which the sound speed varies linearly with
 depth.
 */
struct DepthBandInfo {
   DepthBandInfo(float z_deep, float z_shallow, 
      float c_z_deep, float c_z_shallow);

   /** The altitude of the deep end of the depth band, in meters.
   */
   float z_deep;

   /** The altitude of the shallow end of the depth band, in meters.
   */
   float z_shallow;

   /** Sounds speed at the shallow end of the depth band, in meters/second.
   */
   float c_z_deep;

   /** Sounds speed at the deep end of the depth band, in meters/second.
   */
   float c_z_shallow;

   /**  Produces a string that describes this instance's values.  Intended to
   help with program debugging.
   */
   std::string to_string() const;
};

#endif
