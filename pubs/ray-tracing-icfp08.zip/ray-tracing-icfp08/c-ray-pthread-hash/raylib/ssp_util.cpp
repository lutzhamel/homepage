#include "ssp_util.h"

#include "gen_util.h"
#include <vector>

using namespace std;

//==============================================================================

struct SoundSpeed_at_Depth {
   SoundSpeed_at_Depth(float depth, float speed) :
      speed(speed), depth(depth) {}

   /**
   The speed of sound in meters/second at depth 'depth'.
   */
   float speed;

   /**
   The depth of this datum.
   */
   float depth;
};

//==============================================================================

struct SoundSpeed_at_Z {
   SoundSpeed_at_Z(float z, float speed) :
      speed(speed), z(z) {}

   /**
   The speed of sound in meters/second at altitude 'z'.
   */
   float speed;

   /**
   The altitude of this datum, relative to the ocean floor.
   */
   float z;
};

//==============================================================================

std::vector<SoundSpeed_at_Z> ssp_by_depth_to_ssp_by_z(
      const std::vector<SoundSpeed_at_Depth> & ssp_by_depth) {

   std::vector<SoundSpeed_at_Z> return_vect;

   if (ssp_by_depth.size() == 0) {
      return return_vect;
   }

   float floor_depth = (ssp_by_depth.end() - 1) -> depth;

   for (vector<SoundSpeed_at_Depth>::const_iterator p = ssp_by_depth.begin(); 
         p != ssp_by_depth.end(); ++p) {
      return_vect.push_back(
         SoundSpeed_at_Z( (floor_depth - p->depth), p->speed ));
   }

   return return_vect;
}

//==============================================================================

/**
 Produces a vector of DepthBandInfo that's equivalent in information to the 
 data from the supplied SSP vector.

 The order of elements in both the input and output vectors is important:
 The lower-indexed elements must/will (respectively) describe the shallower
 depths.  This ordering is necessary so that an algorithm that searches through
 the returned vector can rely on the ordering in order to work more efficiently.
 */
std::vector<DepthBandInfo> make_dband_list(
   const std::vector<SoundSpeed_at_Z> & ssp_by_z) {

   vector<DepthBandInfo> return_vect;

   if (ssp_by_z.size() < 2) {
      return return_vect;
   }

   vector<SoundSpeed_at_Z>::const_iterator p1 = ssp_by_z.begin();
   vector<SoundSpeed_at_Z>::const_iterator p2 = p1 + 1; 

   while (p2 != ssp_by_z.end()) {
      return_vect.push_back(DepthBandInfo(p2->z, p1->z, p2->speed, p1->speed));
      ++p1;
      ++p2;
   }

   return return_vect;
}

//==============================================================================

std::vector<DepthBandInfo> load_ssp(std::istream & is) {
   vector<string> lines = readlines(is);

   // Load in the SSP data...
   vector<SoundSpeed_at_Depth> ssp_by_depth;

   for (vector<string>::const_iterator p = lines.begin();
         p != lines.end(); ++p) {
      const string & s = strip(*p);

      // Skip blank lines...
      if (s.length() == 0) {
         continue;
      }

      // Skip comment lines...
      if (s[0] == '#') {
         continue;
      }

      vector<string> data = split(s, ',');
      if (data.size() != 2) {
         string error_str = 
            "A line in the SSP data doesn't look right: ";
         error_str += s;
         throw ExceptionWithString(error_str);
      }

      float depth, speed;

      if (! string_to_type(data[0], depth)) {
         string error_str = 
            "Can't parse the first 'number' of a line in the SSP: ";
         error_str += s;
         throw ExceptionWithString(error_str);
      }

      if (! string_to_type(data[1], speed)) {
         string error_str = 
            "Can't parse the second 'number' of a line in the SSP: ";
         error_str += s;
         throw ExceptionWithString(error_str);
      }

      ssp_by_depth.push_back(SoundSpeed_at_Depth(depth, speed));
   }

   // Convert the SSP data to the form that this funciton must return...
   vector<SoundSpeed_at_Z> ssp_by_z = ssp_by_depth_to_ssp_by_z(ssp_by_depth);
   return make_dband_list(ssp_by_z);
}

//==============================================================================

std::vector<DepthBandInfo>::size_type 
get_dband_idx(const std::vector<DepthBandInfo> & dbands, float z) 
      throw (ExceptionWithString) {
   // Not particulalrly efficient, but that's acceptable at the moment.
   for (std::vector<DepthBandInfo>::size_type i = 0; i < dbands.size(); ++i) {
      const DepthBandInfo & dband = dbands[i];
      if ((dband.z_deep <= z) && (z <= dband.z_shallow)) {
         return i;
      }
   }

   throw ExceptionWithString("Couldn't find specified z value in dbands.");
}

//==============================================================================
