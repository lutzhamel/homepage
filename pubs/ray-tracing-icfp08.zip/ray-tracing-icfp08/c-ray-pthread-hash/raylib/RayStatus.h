#ifndef _RAY_STATUS_H
#define _RAY_STATUS_H

#include <string>

/**
 The status of the ray at any one time.
 */
struct RayStatus {
   float range;
   float z;
   float theta;

   RayStatus(float range, float z, float theta)
      : range(range), z(z), theta(theta) {}

   /**  Produces a string that describes this instance's values.  Intended to
   help with program debugging.
   */
   std::string to_string() const;
};

#endif
