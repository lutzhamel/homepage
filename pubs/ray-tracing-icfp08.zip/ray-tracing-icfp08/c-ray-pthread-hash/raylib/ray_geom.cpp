#include "ray_geom.h"
#include <math.h>

//==============================================================================

int get_circle_horizontal_line_intersections(
      float line_y, float circle_x, float circle_y, float circle_radius,
      float & root1, float & root2) {
   // Eq. for circle: 
   // (x - circle_x)**2 + (y - circle_y)**2 = circle_radius**2
   //
   // In our case, y = line_y, and we're solving for the two values of x:
   // (x - circle_x)**2 = circle_radius**2 - (line_y - circle_y)**2
   //
   // Which becomes:
   // (x - circle_x) = +- sqrt(circle_radius**2 - (line_y - circle_y)**2)
   //
   // Which finally becomes:
   // x = circle_x +- sqrt(circle_radius**2 - (line_y - circle_y)**2)
   
   // Intermediate result, so we can avoid taking sqrt of a negative number.
   float foo = (circle_radius * circle_radius) - 
      (line_y - circle_y) * (line_y - circle_y);

   if (foo < 0) {
      return 0;
      }
   else {
      root1 = circle_x - sqrtf(foo);
      root2 = circle_x + sqrtf(foo);
      return 2;
   }
}

//==============================================================================

int get_circle_vertical_line_intersections(
      float line_x, float circle_x, float circle_y, float circle_radius,
      float & root1, float & root2) {
   // Eq. for circle: 
   // (x - circle_x)**2 + (y - circle_y)**2 = circle_radius**2
   //
   // In our case, x = line_x, and we're solving for the two values of y:
   // (y - circle_y)**2 = circle_radius**2 - (line_x - circle_x)**2
   //
   // Which becomes:
   // (y - circle_y) = +- sqrt(circle_radius**2 - (line_x - circle_x)**2)
   //
   // Which finally becomes:
   // y = circle_y +- sqrt(circle_radius**2 - (line_x - circle_x)**2)
   
   // Intermediate result, so we can avoid taking sqrt of a negative number.
   float foo = (circle_radius * circle_radius) - 
      (line_x - circle_x) * (line_x - circle_x);

   if (foo < 0) {
      return 0;
      }
   else {
      root1 = circle_y - sqrtf(foo);
      root2 = circle_y + sqrtf(foo);
      return 2;
   }
}

//==============================================================================
