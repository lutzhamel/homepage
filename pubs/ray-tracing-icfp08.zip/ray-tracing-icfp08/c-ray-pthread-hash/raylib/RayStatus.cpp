#include "RayStatus.h"

#include "math_util.h"
#include <iostream>
#include <sstream>

using namespace std;


//==============================================================================

std::string RayStatus::to_string() const {
   ostringstream oss(ostringstream::out);
   oss << "RayStatus(this=" << this
      << ", range=" << range
      << ", z=" << z
      << ", theta=" << theta << " rad, " << theta * rad2deg << " deg"
      << ")";
   
   return oss.str();
}

//==============================================================================
