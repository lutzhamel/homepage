#include "ray_trace.h"

#include "ray_geom.h"
#include "ssp_util.h"
#include <math.h>
#include <cassert>
#include <algorithm>

using namespace std;
//==============================================================================

std::string to_string(DepthBandBounraries d) {
   switch (d) {
      case LOW_RANGE_BOUNDARY:
         return "LOW_RANGE_BOUNDARY";
      case HIGH_RANGE_BOUNDARY:
         return "HIGH_RANGE_BOUNDARY";
      case SHALLOW_Z_BOUNDARY:
         return "SHALLOW_Z_BOUNDARY";
      case DEEP_Z_BOUNDARY:
         return "DEEP_Z_BOUNDARY";
      default:
         return "<<< Bogus DepthBandBounraries value! >>>";
   }
}

//==============================================================================

void advance_ray_through_isovelocity_dband(
   float r1, float z1, float theta1,
   float z_shallow, float z_deep, float r_max,
   float & r_exit, float & z_exit, float & theta_exit, 
   DepthBandBounraries & exit_boundary) {

   // Propagation through an isovelocity depth band is straight, so the ray's
   // propagation angle won't change at all.
   theta_exit = theta1;

   if (theta1 > 0) {
      float delta_z = z1 - z_shallow;
      float slope = tanf(theta1);
      float delta_r = fabs(delta_z / slope);
      r_exit = r1 + delta_r;

      // If r_exit > r_max, then the ray actually is going to leave this
      // cell via the r_max boundary, rather than a depth boundary.
      // Handle that by solving for exit depth rather than exit range...
      if (r_exit > r_max) {
         r_exit = r_max;
         delta_r = r_exit - r1;
         z_exit = z1 + slope * delta_r;
         exit_boundary = HIGH_RANGE_BOUNDARY;
      }
      else {
         z_exit = z_shallow;
         exit_boundary = SHALLOW_Z_BOUNDARY;
      }
   }
   else if (theta1 < 0) {
      float delta_z = z_deep - z1;
      float slope = tanf(theta1);
      float delta_r = fabs(delta_z / slope);
      r_exit = r1 + delta_r;

      // If r_exit > r_max, then the ray actually is going to leave this
      // cell via the r_max boundary, rather than a depth boundary.
      // Handle that by solving for exit depth rather than exit range...
      if (r_exit > r_max) {
         r_exit = r_max;
         delta_r = r_exit - r1;
         z_exit = z1 + slope * delta_r;
         exit_boundary = HIGH_RANGE_BOUNDARY;
      }
      else {
         z_exit = z_deep;
         exit_boundary = DEEP_Z_BOUNDARY;
      }
   }
   else {   // theta1 == 0
      z_exit = z1;
      r_exit = r_max;
      exit_boundary = HIGH_RANGE_BOUNDARY;
   }
}

//==============================================================================

void advance_ray_through_constant_gradient_dband(
      float r1, float z1, float theta1, DepthBandBounraries incident_boundary,
      float z_shallow, float z_deep, float r_max, float g,
      float circle_center_r, float circle_center_z, float radius,
      float & r_exit, float & z_exit, float & theta_exit, 
      DepthBandBounraries & exit_boundary) {

   // cout.precision(40);
   // cout << endl;
   // cout << "advance_ray_through_constant_gradient_dband: ENTER" << endl;
   // cout << "@@@ r1:" << r1 << endl;
   // cout << "@@@ z1:" << z1 << endl;
   // cout << "@@@ theta1:" << theta1 << endl;
   // cout << "@@@ incident_boundary:" << to_string(incident_boundary) << endl;
   // cout << "@@@ z_shallow:" << z_shallow << endl;
   // cout << "@@@ z_deep:" << z_deep << endl;

   #if 1
      if (incident_boundary == SHALLOW_Z_BOUNDARY) {
         assert(z1 == z_shallow);
         assert(theta1 < 0);
      }
      else if (incident_boundary == DEEP_Z_BOUNDARY) {
         assert(z1 == z_deep);
         assert(theta1 > 0);
      }
   #endif

   float shallow_root1, shallow_root2;
   int num_shallow_roots = get_circle_horizontal_line_intersections(z_shallow, 
      circle_center_r, circle_center_z, radius,
      shallow_root1, shallow_root2);

   float deep_root1, deep_root2;
   int num_deep_roots = get_circle_horizontal_line_intersections(z_deep, 
      circle_center_r, circle_center_z, radius,
      deep_root1, deep_root2);

   // If we enterered through a vertical boundary, we need to detect the case the 
   // ray just grazing that boundary and reflecting out again.
   // We need to handle this as a special case because numerical
   // precision problems (at least using 32-bit floats) cause the mis-calcuation
   // of theta_exit in these cases.  In the example I found, theta_exit had a
   // negative sign (indicating downward propagation) despite the ray exiting
   // via the SHALLOW boundary.
   //
   // BTW, this is a problem on 32-bit floats on Intel x86, but not on the
   // PowerPC in a Cell for some reason.  Perhaps they have different floating
   // point math?
   //
   // Here are the initial conditions that showed this on x86:
   //    theta1 = 4.442237377166748046875
   //    SSP filename = andrew1.ssp
   //    start_depth = 151
   //    max_range = 10000
   //
   // The problem occurred around range 8638.
   if ((incident_boundary == SHALLOW_Z_BOUNDARY) && (shallow_root1 == shallow_root2) 
         && (g < 0) && (theta1 < 0)) {
      // Treat it like a reflection...
      theta_exit = theta1 * -1;
      r_exit = r1;
      z_exit = z_shallow;
      exit_boundary = SHALLOW_Z_BOUNDARY;
      return;
   }
   else if ((incident_boundary == DEEP_Z_BOUNDARY) && (deep_root1 == deep_root2) 
         && (g > 0) && (theta1 > 0)) {
      // Treat it like a reflection...
      theta_exit = theta1 * -1;
      r_exit = r1;
      z_exit = z_deep;
      exit_boundary = DEEP_Z_BOUNDARY;
      return;
   }

   float far_root1, far_root2;
   get_circle_vertical_line_intersections(r_max, 
      circle_center_r, circle_center_z, radius,
      far_root1, far_root2);

   float shallow_candidate_range = INFINITY;
   float deep_candidate_range = INFINITY;
   float r_max_candidate_depth;
   // Four cases...
   if (g < 0) {
      r_max_candidate_depth = far_root1;

      if (theta1 >= 0) {
         // CASE 1:
         // Ray curves up, and starts up.  It can only intersect shallow or far.
         // If it intersects shallow, it intersects shallow at the 2nd root.
         // If it intersects far, it intersects far at the 1st far root.
         if ((num_shallow_roots > 0) && (shallow_root2 >= r1) && (shallow_root2 < r_max)) {
            shallow_candidate_range = shallow_root2;
         }
      }
      else { assert(theta1 < 0);
         // CASE 2:
         // Ray curves up, but starts down.  It could intersect shallow, deep,
         // or far.  
         // If it intersects shallow, it's at the 2nd shallow root.  
         // If it intersects deep, it's at the 1st deep root.
         // If it intersects far, it intersects far at the 1st far root.
         if ((num_shallow_roots > 0) && (shallow_root2 >= r1) && (shallow_root2 < r_max)) {
            shallow_candidate_range = shallow_root2;
         }

         if ((num_deep_roots > 0) && (deep_root1 >= r1) && (deep_root1 < r_max)) {
            deep_candidate_range = deep_root1;
         }
      }
   }
   else {   assert(g > 0);
      r_max_candidate_depth = far_root2;

      if (theta1 > 0) {
         // CASE 3:
         // Ray curves down, but starts up.  It could intersect shallow, deep,
         // or far.
         // If it intersects shallow, it's at the 1st shallow root.  
         // If it intersects deep, it's at the 2nd deep root.
         // If it intersects far, it intersects far at the 1st far root.
         if ((num_shallow_roots > 0) && (shallow_root1 >= r1) && (shallow_root1 < r_max)) {
            shallow_candidate_range = shallow_root1;
         }

         if ((num_deep_roots > 0) && (deep_root2 >= r1) && (deep_root2 < r_max)) {
            deep_candidate_range = deep_root2;
         }
      }
      else {
         // CASE 4:
         // Ray curves down, and starts down.  It can only intersect deep or far.
         // If it intersects deep, it intersects deep at the 2nd root.
         // If it intersects far, it intersects far at the 2nd root.
         if ((num_deep_roots > 0) && (deep_root2 >= r1) && (deep_root2 < r_max)) {
            deep_candidate_range = deep_root2;
         }
      }
   }

   // This value lets us know if r_exit was assigned to either of
   // {shallow|deep}_candidate_range.
//    r_exit = INFINITY;

   // This test will fail if we never updated shallow_candidate_range (so it's 
   // still INFINITY, which is > r_max), or if shallow_candidate_range is simply
   // > r_max.
   r_exit = r_max;

   if (shallow_candidate_range < r_exit) {
      r_exit = shallow_candidate_range;
      z_exit = z_shallow;
      exit_boundary = SHALLOW_Z_BOUNDARY;
   }

   if (deep_candidate_range < r_exit) {
      r_exit = deep_candidate_range;
      z_exit = z_deep;
      exit_boundary = DEEP_Z_BOUNDARY;
   }

   // If the ray didn't intersect either the shallow or deep dband boundary
   // within our range limits, then the ray must have first crossed r_max.
   // Find out where...
   if (r_exit == r_max) {
//       r_exit = r_max;
      z_exit = r_max_candidate_depth;
      exit_boundary = HIGH_RANGE_BOUNDARY;
   }

   //---------------------------------------------------------------------------
   // Calculate the exit angle...
   //---------------------------------------------------------------------------
   float delta_r = r_exit - circle_center_r;
   float delta_z = z_exit - circle_center_z;
   
   // arctan gives you the angle from between the x-axis (in our case, the 
   // r-axis) and a ray that goes from the circle's center out to the point 
   // (delta_r, delta_z).
   // 
   // In our particular problem, we want to know what the angle of the *tangent* 
   // to the circle is.  It's basically the arctan plus or minus 90 degrees, 
   // where the plus vs. minus issue is decided by the sign of g (that is, the 
   // direction of curvature)...
   //
   // CELL PROGRAMMING NOTE: A great opportunity for eliminating a branch
   // via vectorization.
   if (g < 0) {
      theta_exit = atan2f(delta_z, delta_r) + (M_PI / 2);
   }
   else {
      assert(g > 0);
      theta_exit = atan2f(delta_z, delta_r) - (M_PI / 2);
   }
}

//==============================================================================

void advance_ray_through_dband(
      float r1, float z1, float theta1, DepthBandBounraries incident_boundary,
      float z_shallow, float z_deep, float c_z_shallow, float c_z_deep, 
      float r_max,
      float & r_exit, float & z_exit, float & theta_exit, 
      DepthBandBounraries & exit_boundary) {

   assert(z1 <= z_shallow);
   assert(z1 >= z_deep);

//    float dist_to_terminal_range = r_max - r1;

   // This is the degree of curvature of the ray within this depth band.
   // The sign of this number gives the direction of curvature, and the larger
   // the number, the faster the curvature.
   //
   // This number is also called the 'sound speed gradient'.  It's really 
   // nothing more than the (change in sound speed) over (change in depth).
   float g = float(c_z_deep - c_z_shallow) / (z_deep - z_shallow);

   #if 1
      if ((g < 0) && (theta1 > 0)) {
         assert((incident_boundary == DEEP_Z_BOUNDARY) || (incident_boundary == LOW_RANGE_BOUNDARY));
      }
      else if ((g > 0) && (theta1 < 0)) {
         assert((incident_boundary == SHALLOW_Z_BOUNDARY) || (incident_boundary == LOW_RANGE_BOUNDARY));
      }

   #endif

   // If g == 0.0, then this depth zone has a constant sound speed regardless of
   // depth.  That means the ray will propgate in a straight (but not 
   // necessarily horizontal) line.  We need to handle this case specially 
   // because the calculation for 'radius' (see below) gets a divide-by-zero
   // error if we don't...
   if (g == 0.0) {
      advance_ray_through_isovelocity_dband(
         // The input params...
         r1, z1, theta1, z_shallow, z_deep, r_max,
         // The output params...
         r_exit, z_exit, theta_exit, exit_boundary);
      return;
   }

   // Use interpolation to find the sound speed at altitude z1
   float c_z1 = c_z_deep + g * (z_shallow - z1);

   // This is the radius of curvature for the ray propagation within this 
   // depth band.
   float radius = fabs(c_z1 / (g * cosf(theta1)));
   
   // If you're starting at point (r1, z1), this is the angle that you need to 
   // travel along to get to the center of the circle of rotation.
   //
   // Later on we can perhaps optimize this, if we were going to be taking the
   // cos and sin of theta1 anyway.  Maybe - it's hard to get the cases right
   // possibly.
   float angle_to_circle_center; 
   if (g < 0) {
      // The sound speed decreases as you head towards the surface, so the
      // ray curves upward.  In our case, that means to the +theta direction.
      angle_to_circle_center = theta1 + (M_PI / 2);
   }
   else {
      angle_to_circle_center = theta1 - (M_PI / 2);
   }

   // We know the circle-of-curvature's radius, now determine it's center...
   float circle_center_r = r1 + cosf(angle_to_circle_center) * radius;
   float circle_center_z = z1 + sinf(angle_to_circle_center) * radius;

   advance_ray_through_constant_gradient_dband(
      // The input parameters...
      r1, z1, theta1, incident_boundary,
      z_shallow, z_deep, r_max, g,
      circle_center_r, circle_center_z, radius,
      // The output parameters...
      r_exit, z_exit, theta_exit, exit_boundary);

   #if 1
      if ((g < 0) && (theta1 > 0)) {
         assert((exit_boundary == SHALLOW_Z_BOUNDARY) || (exit_boundary == HIGH_RANGE_BOUNDARY));
      }
      else if ((g > 0) && (theta1 < 0)) {
         assert((exit_boundary == DEEP_Z_BOUNDARY) || (exit_boundary == HIGH_RANGE_BOUNDARY));
      }

   #endif
}

//==============================================================================

std::vector<RayStatus> trace_one_ray(
      const std::vector<DepthBandInfo> & dbands,
      float r1, float z1, float theta1, 
      float r_max, int nbounce_max) {

   // Confirm that theta1 is in the 1st or 4th quadrant...
   if (cosf(theta1) <= 0) cout << "*** " << theta1 << endl;
   assert(cosf(theta1) > 0);

   std::vector<RayStatus> ray_states;
   ray_states.push_back(RayStatus(r1, z1, theta1));

   std::vector<DepthBandInfo>::size_type dband_idx = get_dband_idx(dbands, z1);
   int nbounces = 0;
   
   DepthBandBounraries incident_boundary;

   if (z1 == dbands.at(dband_idx).z_shallow) {
      incident_boundary = SHALLOW_Z_BOUNDARY;
   }
   else if (z1 == dbands.at(dband_idx).z_deep) {
      incident_boundary = DEEP_Z_BOUNDARY;
   }
   else {
      incident_boundary = LOW_RANGE_BOUNDARY;
   }

   const std::vector<DepthBandInfo>::size_type deepest_dband_idx = dbands.size() - 1;

   while ((r1 < r_max) && (nbounces < nbounce_max)) {
      const DepthBandInfo & dband = dbands.at(dband_idx);

      float r_exit, z_exit, theta_exit;
      DepthBandBounraries exit_boundary;

      advance_ray_through_dband(
         // Input parameters...
         r1, z1, theta1, incident_boundary,
         dband.z_shallow, dband.z_deep, dband.c_z_shallow, dband.c_z_deep, 
         r_max,
         // Output parameters...
         r_exit, z_exit, theta_exit, exit_boundary);

      ray_states.push_back(RayStatus(r_exit, z_exit, theta_exit));

      r1 = r_exit;
      z1 = z_exit;

      switch (exit_boundary) {
         case HIGH_RANGE_BOUNDARY:
            // We're done.  Don't need to do anything.
            break;
         case SHALLOW_Z_BOUNDARY:
            if (dband_idx == 0) {
               // Bounce off the ocean's surface...
               theta1 = -1 * theta_exit;
               ++nbounces;
               incident_boundary = SHALLOW_Z_BOUNDARY;
            }
            else {
               theta1 = theta_exit;
               incident_boundary = DEEP_Z_BOUNDARY;
               --dband_idx;
            }
            break;
         case DEEP_Z_BOUNDARY:
            if (dband_idx == deepest_dband_idx) {
               // Bounce off the ocean's floor...
               theta1 = -1 * theta_exit;
               ++nbounces;
               incident_boundary = DEEP_Z_BOUNDARY;
            }
            else {
               theta1 = theta_exit;
               incident_boundary = SHALLOW_Z_BOUNDARY;
               ++dband_idx;
            }
            break;
         default:
            assert(false);
      } // end switch/case
   } // end while loop

   return ray_states;
}

//==============================================================================
