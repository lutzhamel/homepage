#ifndef _RAY_TRACE_H
#define _RAY_TRACE_H

#include "DepthBandInfo.h"
#include "RayStatus.h"
#include <vector>
#include <string>

/**
 These are the four boundaries of a rectangular depth bound box.
 */
typedef enum {
   LOW_RANGE_BOUNDARY,
   HIGH_RANGE_BOUNDARY,
   SHALLOW_Z_BOUNDARY,
   DEEP_Z_BOUNDARY
//    UNSPECIFIED_BOUNDARY
   } DepthBandBounraries;

/**
 Convenienve function to help with debugging.
 */
std::string to_string(DepthBandBounraries d);

/**
 Calculates the depth-band-exit location and direction of a ray entering a 
 constant-sound-speed depth band.

 The function
 assumes that and that the ray's start position is such that
 theta1 points into the depth band rather than immediately out of it.
 (I.e., if theta1 > 0, then (z_deep <= z1 < z_shallow), or that if
 theta1 == 0, then (r1 < r_max) ).
 */
void advance_ray_through_isovelocity_dband(
   float r1, float z1, float theta1,
   float z_shallow, float z_deep, float r_max,
   float & r_exit, float & z_exit, float & theta_exit, 
   DepthBandBounraries & exit_boundary);

/**
 Calculates the depth-band-exit location and direction of a ray entering a 
 constant-gradient-sound-speed depth band.

 This is specifically for depth bands that do *not* have a constant sound speed
 within the depth band, but instead have a sound speed that varies linearly with
 depth.  Propagation in such a depth band is exactly circular.  The center and
 radius of that circle are dependent on details about the ray's start position
 and direction, which this function receives as input parameters.
 */
void advance_ray_through_constant_gradient_dband(
   float r1, float z1, float theta1, DepthBandBounraries incident_boundary,
   float z_shallow, float z_deep, float r_max, float g,
   float circle_center_r, float circle_center_z, float radius, 
   float & r_exit, float & z_exit, float & theta_exit, 
   DepthBandBounraries & exit_boundary);

/**
 This function advances a ray through a depth band, regardless of whether that
 band is isovelocity or constant-gradient.  This function is a little less
 trivial than you might think, because for a constant-gradient depth band this
 function also calculates the propagation path's center and radius.

 NOTE: If we ever refactor this code, we should consider moving all of the
 circle-calculation logic into 'advance_ray_through_constant_gradient_dband',
 which might eliminate this function's reason for existence because it's 
 internal logic might be trivial at that point.
 */
void advance_ray_through_dband(
   float r1, float z1, float theta1, DepthBandBounraries incident_boundary,
   float z_shallow, float z_deep, float c_z_shallow, float c_z_deep, 
   float r_max,
   float & r_exit, float & z_exit, float & theta_exit, 
   DepthBandBounraries & exit_boundary);
   

/**

IMPLEMENTATION NOTES:
* When we port this function to the Cell SPE, we should look at replacing 
  the use of vectors with arrays.  Vector looks ( operator[] ) in GCC's STL
  implementation involve several levels of indirection each time you call [].

  Alternatively, we could abuse the fact that vector<>.begin() returns a 
  pointer to the vector's internal array of elements, and do indexing on 
  that.

  As far as how this function returns its list of results, we'll want to revisit
  that as well.  In general, it seems a shame to have the SPE do such an awesome
  job ripping through the math, only to spend most of its time getting data
  into and out of STL containers.  I guess that's what profilers are for, 
  though.

  Returns a vector with details about the ray's location and direction at 
  various points in its propagation.  This vector will include the ray's
  initial status.
 */

std::vector<RayStatus> trace_one_ray(
   const std::vector<DepthBandInfo> & dbands,
   float r1, float z1, float theta1, 
   float r_max, int nbounce_max);

#endif

