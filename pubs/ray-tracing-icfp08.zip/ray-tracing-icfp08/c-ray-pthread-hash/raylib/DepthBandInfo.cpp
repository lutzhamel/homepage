#include "DepthBandInfo.h"

#include <iostream>
#include <sstream>

using namespace std;

//==============================================================================

DepthBandInfo::DepthBandInfo(float z_deep, float z_shallow, 
      float c_z_deep, float c_z_shallow) 
   : z_deep(z_deep), z_shallow(z_shallow), 
     c_z_deep(c_z_deep), c_z_shallow(c_z_shallow) {
}

//==============================================================================

std::string DepthBandInfo::to_string() const {
   ostringstream oss(ostringstream::out);
   oss << "DepthBandInfo(this=" << this
      << ", z_shallow=" << z_shallow
      << ", z_deep=" << z_deep
      << ", c_z_shallow=" << c_z_shallow
      << ", c_z_deep=" << c_z_deep
      << ")";
   
   return oss.str();
}

//==============================================================================
