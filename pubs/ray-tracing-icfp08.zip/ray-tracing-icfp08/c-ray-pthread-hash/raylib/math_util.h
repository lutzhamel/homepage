#ifndef _MATH_UTIL_H
#define _MATH_UTIL_H

extern const float rad2deg;
extern const float deg2rad;

/**
 Returns 'true' iff x and y differ by less than epsilon.
 */
bool is_near(float x, float y, float epsilon);

#endif
