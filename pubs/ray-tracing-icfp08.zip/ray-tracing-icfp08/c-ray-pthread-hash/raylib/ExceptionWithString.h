#ifndef _EXCEPTIONWITHSTRING_H
#define _EXCEPTIONWITHSTRING_H

#include <exception>
#include <string>

class ExceptionWithString : public std::exception {
   public:
      ExceptionWithString(const std::string & what);
      virtual ~ExceptionWithString() throw ();

      virtual const char* what() const throw();

   private:
      std::string what_string;
};

#endif
