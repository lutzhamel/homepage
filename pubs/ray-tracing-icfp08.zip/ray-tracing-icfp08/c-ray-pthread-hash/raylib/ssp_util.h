#include <iostream>
#include <vector>
#include <string>

#include "DepthBandInfo.h"
#include "ExceptionWithString.h"

//==============================================================================

/**
The ssp must be given in a text file where each line is of the form
   depth, speed
The depth values must increase with the line number in the file.
Don't have any blank lines.

This function will output a depth-band list.  Note that the input file 
expresses altitude in terms of depth, which increases towards the center
of the earth.  But the returned depth-band list uses 'z' values, which 
are 0 are the ocean floor and increase towards the sky.
*/
std::vector<DepthBandInfo> load_ssp(std::istream & is);

/**
Given that dband_list is a Python list of depth bands (one dictionary
per depth band), this gives the index number into the list for the depth
band that contains altitude 'z'.
*/
std::vector<DepthBandInfo>::size_type 
get_dband_idx(const std::vector<DepthBandInfo> & dbands, float z) 
      throw (ExceptionWithString);
