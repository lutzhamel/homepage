#include "gen_util.h"

using namespace std;

//==============================================================================

std::vector<std::string> readlines(istream & is, int line_buffer_bytes)
      throw (ExceptionWithString) {

   vector<string> v;

   char * pLineBuffer = new char[line_buffer_bytes];

   if (is.fail()) {
      delete [] pLineBuffer;
      throw ExceptionWithString(string("Failed to load SSP from stream."));
   }

   while (! is.eof()) {
      is.getline(pLineBuffer, line_buffer_bytes);

      if ((! is.eof()) && is.fail()) {
         delete [] pLineBuffer;
         throw ExceptionWithString(string("Failed to load SSP from stream."));
      }

      v.push_back(string(pLineBuffer));
   }

   delete [] pLineBuffer;
   return v;
}

//==============================================================================

std::string strip(const std::string & s) {
   string::size_type pos1 = s.find_first_not_of(" \t\n\r");
   if (pos1 == string::npos) {
      return "";
   }

   string::size_type pos2 = s.find_last_not_of(" \t\n\r");
   return s.substr(pos1, pos2 - pos1 + 1);
}

//==============================================================================

std::vector<std::string> split(const std::string & s, const char c) {
   vector<string> results;

   string::size_type pos1 = s.find_first_not_of(c);

   while (pos1 != string::npos) {
      string::size_type pos2 = s.find_first_of(c, pos1);

      if (pos2 == string::npos) {
         results.push_back(s.substr(pos1));
         break;
      }
      else {
         string::size_type len = pos2 - pos1;
         results.push_back(s.substr(pos1, len));

         pos1 = s.find_first_not_of(c, pos2 + 1);
      }
   }

   return results;
}

//==============================================================================
