#ifndef _RAY_GEOM_H
#define _RAY_GEOM_H

/**
Determines the ranges at which the circle intersects the specified line.
If there is no intersection this returns an empty list.
The entries may include negatives, but the first value will definitely be
<= the second value.  (first value = second value in the case of a
tangental intersection).

Returns the number of real roots that were found: either 0 or 2.
A double-root is treated as two real roots that just happen to have the
same value, so a double-root has a return-value of 2, not 1.

If the return value is 0, then 'root1' and 'root2' are not modified.
If the return value is 2, then they're both set to the roots.
It will always be the case that root1 < root2 when this returns.
*/
int get_circle_horizontal_line_intersections(
      float line_y, float circle_x, float circle_y, float circle_radius,
      float & root1, float & root2);

/**
Same as get_circle_horizontal_line_intersections, but for a vertical line.
*/
int get_circle_vertical_line_intersections(
      float line_x, float circle_x, float circle_y, float circle_radius,
      float & root1, float & root2);


#endif
