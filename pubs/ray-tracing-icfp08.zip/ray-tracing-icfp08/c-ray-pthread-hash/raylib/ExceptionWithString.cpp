#include "ExceptionWithString.h"

using namespace std;

ExceptionWithString::ExceptionWithString(const string & what)
   : what_string(what) {
}

ExceptionWithString::~ExceptionWithString() throw () {
}


const char* ExceptionWithString::what() const throw() {
   return what_string.c_str();
}
