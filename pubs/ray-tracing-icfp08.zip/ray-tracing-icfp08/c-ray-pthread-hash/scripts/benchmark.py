#!/usr/bin/python
import os

prog_name = "../c-ray/c-ray"
rays_increment = 100000
max_rays = 1000000
num_worker_threads = 4

for rays in range(rays_increment, max_rays+1, rays_increment):
   cmd = "/usr/bin/time -f \"" + str(rays) + " %e\" " + \
      prog_name + " ../data/andrew1.ssp " + str(num_worker_threads) + " -45 45 " + str(rays) + " 151 10000 30"
   print "CMD = " + cmd
   os.system(cmd)
