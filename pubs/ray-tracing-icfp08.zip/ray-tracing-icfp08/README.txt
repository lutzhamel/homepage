This directory contains the three programs mentioned in our IFCP08 paper, 
"Experience Report: Erland in Acoustic Ray Tracing".

The programs in this directory are as follows:

--------------------------------------------------------------------------------

"c-ray-pthread-hash" contains the C++ implementation of the acoustic ray
tracing algorithm.  You'll want CMake (http://cmake.org) to build this
program.  It's a standard C++/pthreads program.  It should build easily
on Linux, and probably just as easily on Mac OS X as well.

To build and run the code, one might type the following commands:
   cd c-ray-pthread-hash
   cmake .
   make
   c-ray/c-ray data/andrew1.ssp 4 -45 45 1000 101 10000 30
   
Running c-ray/c-ray without any command-line parameters will print out
the command-line usage of the program.  For benchmarking, the two most
interesting parameters are <num-worker-threads> and <num-rays>, which 
are "4" and "1000", respectively, in the example above.

A very simple script for testing the program's performance scalabilty can be 
found in the 'scripts' subdirectory.

--------------------------------------------------------------------------------

"e-ray-multiproc-hash" contains our first Erlang implementation of the 
acoustic ray tracing algorithm.  This is the program labelled as 
"Erlang (v.1)" in our performance graphs.

To build this code, you'll want the Erlang HiPE virtual machine installed.  Then
one types the following commands:
   cd e-ray-multiproc-hash
   erl
   c(build).
   build:native().
   
Having done that, one runs the algorithm with the following command within the
Erlang shell:
   c(benchmark).
   benchmark:dotest(NumProcs, NumTests).

--------------------------------------------------------------------------------

"e-ray-multiproc-hash2" contains our second, more carefully tuned
Erlang implementation of the acoustic ray tracing algorithm.  This is 
the program labelled as "Erlang (v.2)" in our performance graphs.

This program is compiled in exactly the same manner as "e-ray-multiproc-hash".
The benchmark function included with this version of the program has s slightly
different signature:
   benchmark:dotest(NumProcs, NumTests, NumRays).

--------------------------------------------------------------------------------
