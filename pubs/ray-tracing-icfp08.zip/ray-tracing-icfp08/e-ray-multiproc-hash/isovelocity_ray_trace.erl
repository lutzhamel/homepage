-module(isovelocity_ray_trace).
-export([advance_ray_through_isovelocity_band/6]).
-import_all(ray_geom).

% Returns {R_exit, Z_exit, Theta_exit, Exit_boundary}
advance_ray_through_isovelocity_band(
      R1, Z1, Theta1,
      Z_shallow, Z_deep, R_max) ->

   % Propagation through an isovelocity depth band is straight, so the ray's
   % propagation angle won't change at all.
   Answer_theta_exit = Theta1,

   if 
      Theta1 > 0.0 ->
         % Assume that the ray is going to exit the cell via depth boundary.
         % Backtrack on this later if necessary...
         Test1_delta_z = Z1 - Z_shallow,
         Test1_slope = math:tan(Theta1),
         Test1_delta_r = abs(Test1_delta_z / Test1_slope),
         Test1_r_exit = R1 + Test1_delta_r,

         % If r_exit > r_max, then the ray actually is going to leave this
         % cell via the r_max boundary, rather than a depth boundary.
         % Handle that by solving for exit depth rather than exit range...
         if 
            Test1_r_exit > R_max ->
               Answer_r_exit = R_max,
               Test2_delta_r = Answer_r_exit - R1,
               Answer_z_exit = Z1 + Test1_slope * Test2_delta_r,
               Answer_exit_boundary = high_range_boundary;
            true ->
               Answer_r_exit = Test1_r_exit,
               Answer_z_exit = Z_shallow,
               Answer_exit_boundary = shallow_z_boundary
         end;

      Theta1 < 0.0 ->      
         % Assume that the ray is going to exit the cell via depth boundary.
         % Backtrack on this later if necessary...
         Test1_delta_z = Z_deep - Z1,
         Test1_slope = math:tan(Theta1),
         Test1_delta_r = abs(Test1_delta_z / Test1_slope),
         Test1_r_exit = R1 + Test1_delta_r,

         % If r_exit > r_max, then the ray actually is going to leave this
         % cell via the r_max boundary, rather than a depth boundary.
         % Handle that by solving for exit depth rather than exit range...
         if 
            Test1_r_exit > R_max ->
               Answer_r_exit = R_max,
               Test2_delta_r = Answer_r_exit - R1,
               Answer_z_exit = Z1 + Test1_slope * Test2_delta_r,
               Answer_exit_boundary = high_range_boundary;
            true ->
               Answer_r_exit = Test1_r_exit,
               Answer_z_exit = Z_shallow,
               Answer_exit_boundary = deep_z_boundary
         end;

      true ->
         %  Theta1 =:= 0.0 ...
         Answer_z_exit = Z1,
         Answer_r_exit = R_max,
         Answer_exit_boundary = high_range_boundary
   end,
   {Answer_r_exit, Answer_z_exit, Answer_theta_exit, Answer_exit_boundary}.
