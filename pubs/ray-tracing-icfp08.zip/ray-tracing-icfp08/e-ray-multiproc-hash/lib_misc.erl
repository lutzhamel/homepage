-module(lib_misc).
-compile(export_all).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This code is a complete or nearly complete
% copy of the example code given in 
% Joe Armstrong's "Programming Erlang" book,
% page 368.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




% smp_pmap(Func, Args) ->
%    SelfPid = self(),
%    Ref = erlang:make_ref(),
% 
%    SpawnOneCall = fun(Func, Arg) ->
% 
%    lists:foreach


pmap1(F, L) ->
   S = self(),
   Ref = erlang:make_ref(),
   lists:foreach(fun(I) ->
      spawn(fun() -> do_f1(S, Ref, F, I) end)
      end, L),

   %% gather the results
   gather1(length(L), Ref, [])
.

do_f1(Parent, Ref, F, I) ->
   Parent ! {Ref, (catch F(I))}
.

gather1(0, _, L) -> L
;
gather1(N, Ref, L) ->
   receive 
      {Ref, Ret} -> gather1(N-1, Ref, [Ret|L])
   end
.

