-module(build).
-compile(export_all).

native() ->
   Files = [
      lib_misc,
      benchmark,
      build,
      constant_gradient_ray_trace, 
      dband,
      isovelocity_ray_trace,
      ray_geom,
      ray_math,
      ray_trace],

   lists:map( (fun(X) -> compile:file(X, [return_errors, native, {hipe, [o3]}]) end), Files)
.


native_trace() ->
   Files = [
      lib_misc,
      benchmark,
      build,
      constant_gradient_ray_trace, 
      dband,
      isovelocity_ray_trace,
      ray_geom,
      ray_math,
      ray_trace],

   lists:map( (fun(X) -> compile:file(X, [return_errors, native, trace, {hipe, [o3]}]) end), Files)
.


debug() ->
   Files = [
      lib_misc,
      benchmark,
      build,
      constant_gradient_ray_trace, 
      dband,
      isovelocity_ray_trace,
      ray_geom,
      ray_math,
      ray_trace],

   lists:map( (fun(X) -> compile:file(X, [return_errors, debug_info]) end), Files)
.