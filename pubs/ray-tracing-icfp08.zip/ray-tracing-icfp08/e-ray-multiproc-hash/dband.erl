-module(dband).
-export([load_ssp/1, ssp_to_dband_info_list/1 ]).
-include("dband_info.hrl").

%===============================================================================

% Returns a list of the non-comment lines from an SSP file.  The lists is 
% ordered according to increasing line-number from the file.
%
% Each list element is a two-tuple of the form {Z, Speed}.
read_ssp_lines(S, LinesSoFar) ->
   Line = io:get_line(S, ''),
   if Line == eof ->
      LinesSoFar
   ;  true ->
      FirstChar = lists:nth(1, Line),
      if FirstChar == $# ->
         % Skip over comment lines.
         read_ssp_lines(S, LinesSoFar)
      ;  true ->
         {Status, Tokens, _} = io_lib:fread("~d,\t~d", Line),
         case Status of
            ok -> 
               [Z, SoundSpeed] = Tokens,
               read_ssp_lines(S, [ {Z, SoundSpeed} | LinesSoFar ])
         end
      end
   end
.

%===============================================================================

load_ssp(Filename) ->
   {ok, S} = file:open(Filename, read),
   read_ssp_lines(S, [])
.

%===============================================================================

ssp_to_dband_info_list(SspLines) ->
   lists:reverse(ssp_to_dband_info_list1(SspLines, []))
.

ssp_to_dband_info_list1(SspLines, ListAcc) ->
   if (length(SspLines) < 2) ->
      ListAcc
   ; true ->
      [{ShallowZ, ShallowSpeed} | T] = SspLines,
      [{DeepZ, DeepSpeed} | _] = T,
      Info = #dband_info{
         z_shallow = ShallowZ, c_z_shallow = ShallowSpeed,
         z_deep = DeepZ, c_z_deep = DeepSpeed},
      ssp_to_dband_info_list1(T, [Info | ListAcc])
   end
.

%===============================================================================