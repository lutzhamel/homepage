-module(ray_geom).
-compile(export_all).

% Returns one of two values:
% {Root1, Root2} when there are two real-valued roots (possible the same value),
% or { {}, {} } when there is no real-valued root.
get_circle_horizontal_line_intersections(
      Line_y, Circle_x, Circle_y, Circle_radius) ->

   % Eq. for circle: 
   % (x - circle_x)**2 + (y - circle_y)**2 = circle_radius**2
   % 
   % In our case, y = line_y, and we're solving for the two values of x:
   % (x - circle_x)**2 = circle_radius**2 - (line_y - circle_y)**2
   % 
   % Which becomes:
   % (x - circle_x) = +- sqrt(circle_radius**2 - (line_y - circle_y)**2)
   % 
   % Which finally becomes:
   % x = circle_x +- sqrt(circle_radius**2 - (line_y - circle_y)**2)
   
   % Intermediate result, so we can avoid taking sqrt of a negative number.
   Delta_y = Line_y - Circle_y,
   Foo = (Circle_radius * Circle_radius) - Delta_y * Delta_y,
   if
      (Foo < 0) ->
         ReturnVal = {{}, {}};
      true ->
         SqrtFoo = math:sqrt(Foo),
         ReturnVal = {Circle_x - SqrtFoo, Circle_x + SqrtFoo}
   end,
   ReturnVal.
   

% Returns one of two values:
% {Root1, Root2} when there are two real-valued roots (possible the same value),
% or { {}, {} } when there is no real-valued root.
get_circle_vertical_line_intersections(
      Line_x, Circle_x, Circle_y, Circle_radius) ->

   % Eq. for circle: 
   % (x - circle_x)**2 + (y - circle_y)**2 = circle_radius**2
   % 
   % In our case, x = line_x, and we're solving for the two values of y:
   % (y - circle_y)**2 = circle_radius**2 - (line_x - circle_x)**2
   % 
   % Which becomes:
   % (y - circle_y) = +- sqrt(circle_radius**2 - (line_x - circle_x)**2)
   % 
   % Which finally becomes:
   % y = circle_y +- sqrt(circle_radius**2 - (line_x - circle_x)**2)
   
   % Intermediate result, so we can avoid taking sqrt of a negative number.
   Delta_x = Line_x - Circle_x,
   Foo = (Circle_radius * Circle_radius) - Delta_x * Delta_x,
   if
      (Foo < 0) ->
         ReturnVal = {{}, {}};
      true ->
         SqrtFoo = math:sqrt(Foo),
         ReturnVal = {Circle_y - SqrtFoo, Circle_y + SqrtFoo}
   end,
   ReturnVal.
