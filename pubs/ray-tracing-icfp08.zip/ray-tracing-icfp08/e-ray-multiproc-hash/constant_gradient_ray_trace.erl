-module(constant_gradient_ray_trace).
% -compile(export_all).
-import_all(ray_geom).
-export([advance_ray_through_constant_gradient_dband/10]).

%===============================================================================

is_shallow_grazing(
         Incident_boundary, G, Theta1, 
         NumShallowRoots, ShallowRoot1, ShallowRoot2) ->
      (Incident_boundary == shallow_z_boundary) and
      (G < 0) and
      (Theta1 < 0) and
      (NumShallowRoots =:= 2) andalso
      (ShallowRoot1 =:= ShallowRoot2)
.

%===============================================================================

is_deep_grazing(
         Incident_boundary, G, Theta1, 
         NumDeepRoots, DeepRoot1, DeepRoot2) ->
      (Incident_boundary == deep_z_boundary) and
      (G > 0) and
      (Theta1 > 0) and
      (NumDeepRoots =:= 2) andalso
      (DeepRoot1 =:= DeepRoot2)
.

%===============================================================================

% Returns {R_exit, Z_exit, Theta_exit, Exit_boundary}
%
% Should only be called when is_shallow_grazing(...) returned true.
get_exit_when_shallow_grazing(Theta1, R1, Z_shallow) ->
   R_exit = R1,
   Z_exit = Z_shallow,
   Theta_exit = Theta1 * -1,
   Exit_boundary = shallow_z_boundary,
   {R_exit, Z_exit, Theta_exit, Exit_boundary}
.

%===============================================================================

% Returns {R_exit, Z_exit, Theta_exit, Exit_boundary}
%
% Should only be called when is_deep_grazing(...) returned true.
get_exit_when_deep_grazing(Theta1, R1, Z_deep) ->
   R_exit = R1,
   Z_exit = Z_deep,
   Theta_exit = Theta1 * -1,
   Exit_boundary = deep_z_boundary,
   {R_exit, Z_exit, Theta_exit, Exit_boundary}
.

%===============================================================================

is_valid_range(R, LB, UB) ->
   case R of 
      {} -> false;
      _ when is_number(R) and is_number(LB) and is_number(UB) ->
         (R >= LB) and (R < UB)
   end
.

%===============================================================================

% Returns {R_exit, Z_exit, Theta_exit, Exit_boundary}
%
% Should only be called when is_deep_grazing(...) returned false and
% is_shallow_grazing() returned false.
get_exit_when_nongrazing(
      Theta1, R1, R_max, Z_shallow, Z_deep,
      G, Circle_center_r, Circle_center_z, Radius,
      ShallowRoot1, ShallowRoot2,
      DeepRoot1, DeepRoot2) ->


   {FarRoot1, FarRoot2} = ray_geom:get_circle_vertical_line_intersections(
         R_max, Circle_center_r, Circle_center_z, Radius),

   %----------------------------------------------------------------------------
   % Depending on the curvature of the rays (sign of G) and on the ray's initial
   % angle (Theta1), we pick up at most one point point along each of the three 
   % interesting boundaries (shallow, deep, far) where the ray intersects that 
   % boundary.
   % 
   % We use the roots of where (if anywhere) the circle intersects each 
   % boundary.  Then, based on G and Theta1, we can know for each boundary which
   % if any of those 0 or 2 points of intersection represents the one that the
   % ray would *first* traverse.  We use InfiniteRange to indicate that a ray
   % will simply not cross that boundary of the rectangular cell.
   % 
   % There are four cases...
   %----------------------------------------------------------------------------
   InfiniteRange = R_max + 1000000,

   if
      (G < 0) ->
         % CASES 1 and 2: Ray curves up...
         R_max_candidate_depth = FarRoot1,

         Shallow_candidate_range = 
            case is_valid_range(ShallowRoot2, R1, R_max) of
               true  -> ShallowRoot2;
               false -> InfiniteRange
            end,

         Deep_candidate_range = 
            if 
               (Theta1 >= 0) ->
                  % CASE 1:
                  % Ray curves up, and starts up.  It can only intersect shallow or far.
                  % If it intersects shallow, it intersects shallow at the 2nd root.
                  % If it intersects far, it intersects far at the 1st far root.
                  InfiniteRange
               ;
               (Theta1 < 0) ->
                  % CASE 2:
                  % Ray curves up, but starts down.  It could intersect shallow, deep,
                  % or far.  
                  % If it intersects shallow, it's at the 2nd shallow root.  
                  % If it intersects deep, it's at the 1st deep root.
                  % If it intersects far, it intersects far at the 1st far root.
                  case is_valid_range(DeepRoot1, R1, R_max) of
                     true  -> DeepRoot1;
                     false -> InfiniteRange
                  end
            end
      ;
      (G > 0) ->
         % CASES 3 and 4: Ray curves down...
         R_max_candidate_depth = FarRoot2,

         Shallow_candidate_range = 
            if
               (Theta1 > 0) ->
                  % CASE 3:
                  % Ray curves down, but starts up.  It could intersect shallow, deep,
                  % or far.
                  % If it intersects shallow, it's at the 1st shallow root.  
                  % If it intersects deep, it's at the 2nd deep root.
                  % If it intersects far, it intersects far at the 1st far root.
                  case is_valid_range(ShallowRoot1, R1, R_max) of
                     true  -> ShallowRoot1;
                     false -> InfiniteRange
                  end

               ;
               (Theta1 =< 0) ->
                  % CASE 4:
                  % Ray curves down, and starts down.  It can only intersect deep or far.
                  % If it intersects deep, it intersects deep at the 2nd root.
                  % If it intersects far, it intersects far at the 2nd root.
                  InfiniteRange
            end,

         Deep_candidate_range = 
            case is_valid_range(DeepRoot2, R1, R_max) of
               true  -> DeepRoot2;
               false -> InfiniteRange
            end
   end,

   %----------------------------------------------------------------------------
   % Of all boundaries' candidate range, determine the one that has the lowest
   % range.  (The lowest range will still be > R1, because we ensured that in
   % the code above.)  That represents the next boundary through which the ray
   % will traverse.
   %----------------------------------------------------------------------------
   CandidateRanges = [ 
      {Shallow_candidate_range, shallow_z_boundary},
      {Deep_candidate_range,    deep_z_boundary},
      {R_max,                   high_range_boundary} ],

   % This selects the element in CandidateRanges with the smallest range
   % (the smallest value in the first element of any tuple in the list).
   { R_exit, Exit_boundary } = lists:min(CandidateRanges),
   Z_exit = case Exit_boundary of
      shallow_z_boundary -> Z_shallow;
      deep_z_boundary -> Z_deep;
      high_range_boundary -> R_max_candidate_depth
      end,

   % Determine the angle at which the ray will be travelling as it leaves this
   % rectangular cell...
   Delta_r = R_exit - Circle_center_r,
   Delta_z = Z_exit - Circle_center_z,

   Theta_exit = 
      if
         (G < 0) ->
            math:atan2(Delta_z, Delta_r) + (math:pi() / 2)
         ;
         (G > 0) ->
            math:atan2(Delta_z, Delta_r) - (math:pi() / 2)
      end,   

   {R_exit, Z_exit, Theta_exit, Exit_boundary}
.

%===============================================================================

% Returns {R_exit, Z_exit, Theta_exit, Exit_boundary}
advance_ray_through_constant_gradient_dband(
      R1, Theta1, Incident_boundary,
      Z_shallow, Z_deep, R_max, G,
      Circle_center_r, Circle_center_z, Radius) ->

   {ShallowRoot1, ShallowRoot2} = ray_geom:get_circle_horizontal_line_intersections(
         Z_shallow, Circle_center_r, Circle_center_z, Radius),
   NumShallowRoots =
      case ShallowRoot1 of
         {} -> 0;
         _ -> 2
      end,

   {DeepRoot1, DeepRoot2} = ray_geom:get_circle_horizontal_line_intersections(
      Z_deep, Circle_center_r, Circle_center_z, Radius),
   NumDeepRoots =
      case DeepRoot1 of
         {} -> 0;
         _ -> 2
      end,

   % If we enterered through a vertical boundary, we need to detect the case the 
   % ray just grazing that boundary and reflecting out again.
   % We need to handle this as a special case because numerical
   % precision problems (at least using 32-bit floats) cause the mis-calcuation
   % of theta_exit in these cases.  In the example I found, theta_exit had a
   % negative sign (indicating downward propagation) despite the ray exiting
   % via the shallow boundary.
   IsShallowGrazing = is_shallow_grazing(Incident_boundary, G, Theta1, NumShallowRoots, ShallowRoot1, ShallowRoot2),
   if 
      IsShallowGrazing -> 
         get_exit_when_shallow_grazing(Theta1, R1, Z_shallow)
         ;
      true ->
         IsDeepGrazing = is_deep_grazing(Incident_boundary, G, Theta1, NumDeepRoots, DeepRoot1, DeepRoot2),
         if 
            IsDeepGrazing ->
               get_exit_when_deep_grazing(Theta1, R1, Z_deep)
               ;
            true ->
               % The ray is grazes neither the shallow nor the deep boundary, so
               % do the typical (i.e., non-corner-case) calculation for where the 
               % ray exits the cell...
               get_exit_when_nongrazing(
                     Theta1, R1, R_max, Z_shallow, Z_deep,
                     G, Circle_center_r, Circle_center_z, Radius,
                     ShallowRoot1, ShallowRoot2,
                     DeepRoot1, DeepRoot2)
         end
   end
.
