-module(benchmark).
-compile(export_all).
-include("ray_status.hrl").


%===============================================================================

assert(P, Msg) ->
   case P of
      true -> {};
      false -> exit(Msg);
      _ -> exit("Problem: assert(...) called with a non-Boolean predicate.")
   end
.
%===============================================================================

pretty_print_ray_status(R) ->
   ["#ray_status:" | lists:zip(record_info(fields, ray_status),tl(tuple_to_list(R)))]
.

%===============================================================================

print_ray_status_list([]) -> {}
;

print_ray_status_list([H|T]) ->
   io:format("~p~n", [pretty_print_ray_status(H)]),
   print_ray_status_list(T)
.

%===============================================================================

dotest(NumProcs, NumTests) ->
	C1 = fun(N) -> 
		io:format("N:~p, NumProcs:~p", [N, NumProcs]), 
		ClockSecs = ray_trace:trace_many_rays(-45, 45, 100000, NumProcs), 
		io:format("  Clock time:~p~n", [ClockSecs]),
		erlang:garbage_collect()
		end,

	lists:map(C1, lists:seq(1,NumTests))
.

%===============================================================================
% 
% profile_one_ray(Theta1) ->
%    Ssp = dband:load_ssp("andrew1.ssp"),
%    DbandInfoList = dband:ssp_to_dband_info_list(Ssp),
% 
%    R1 = 0,
%    Z1 = 151,
%    Theta1 = StartDeAngle * (math:pi() / 180),
%    R_max = 10000,
%    NBounce_max = 50,
% 
%    eprof:profile([self()], ray_trace, trace_one_ray, [DbandInfoList, R1, Z1, Theta1, R_max, NBounce_max])
% %    OneTrace = ray_trace:trace_one_ray(DbandInfoList, R1, Z1, Theta1, R_max, NBounce_max),
% 
% 
% %    print_ray_status_list(OneTrace)
% .
