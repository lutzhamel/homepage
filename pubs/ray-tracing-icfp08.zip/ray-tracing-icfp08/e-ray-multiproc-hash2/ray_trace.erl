-module(ray_trace).
-compile(export_all).

-define(rec_info(T,R),lists:zip(record_info(fields,T),tl(tuple_to_list(R)))).

-include("dband_info.hrl").
-include("ray_status.hrl").

%===============================================================================

assert(P, Msg) ->
   case P of
      true -> {};
      false -> exit(Msg);
      _ -> exit("Problem: assert(...) called with a non-Boolean predicate.")
   end
.

%===============================================================================

% Returns {R_exit, Z_exit, Theta_exit, Exit_boundary}
advance_ray_through_dband(
      R1, Z1, Theta1, Incident_boundary, 
      Z_shallow, Z_deep, C_z_shallow, C_z_deep,
      R_max) ->

   % Some input validation...
   assert((Z_shallow > Z_deep), "Bad input: Z_shallow <= Z_deep"),

   % This is the degree of curvature of the ray within this depth band.
   % The sign of this number gives the direction of curvature, and the larger
   % the number, the faster the curvature.
   % 
   % This number is also called the 'sound speed gradient'.  It's really 
   % nothing more than the (change in sound speed) over (change in altitude).
   G = (C_z_deep - C_z_shallow) / (Z_deep - Z_shallow),

   if
      (G =:= 0) ->
         % If g == 0.0, then this depth zone has a constant sound speed 
         % regardless of depth.  That means the ray will propgate in a straight 
         % (but not necessarily horizontal) line.  We need to handle this case 
         % specially  because the calculation for 'radius' (see below) gets a 
         % divide-by-zero error if we don't...
         isovelocity_ray_trace:advance_ray_through_isovelocity_band(
               R1, Z1, Theta1, Z_shallow, Z_deep, R_max)
      ;
      (G =/= 0) ->
         % Use interpolation to find the sound speed at altitude z1
         C_z1 = C_z_deep + G * (Z_shallow - Z1),
         
         % This is the radius of curvature for the ray propagation within this
         % depth band.
         Radius = abs(C_z1 / (G * math:cos(Theta1))),

         % If you're starting at point (r1, z1), this is the angle that you need to 
         % travel along to get to the center of the circle of rotation.
         % 
         % Later on we can perhaps optimize this, if we were going to be taking the
         % cos and sin of theta1 anyway.  Maybe - it's hard to get the cases right
         % possibly.
         Angle_to_circle_center = 
            if 
               (G < 0) -> Theta1 + (math:pi() / 2)
               ;
               (G > 0) -> Theta1 - (math:pi() / 2)
            end,

         Circle_center_r = R1 + math:cos(Angle_to_circle_center) * Radius,
         Circle_center_z = Z1 + math:sin(Angle_to_circle_center) * Radius,

         constant_gradient_ray_trace:advance_ray_through_constant_gradient_dband(
               R1, Theta1, Incident_boundary,
               Z_shallow, Z_deep, R_max, G,
               Circle_center_r, Circle_center_z, Radius)
   end
.

%===============================================================================

get_index_of(List, MatchPredicate) ->
   get_index_of(List, MatchPredicate, 1)
.

get_index_of([H | T], MatchPredicate, IndexIfHeadMatches) ->
   case MatchPredicate(H) of
      true  -> IndexIfHeadMatches;
      false -> get_index_of(T, MatchPredicate, IndexIfHeadMatches + 1)
   end
;

get_index_of([], _MatchPredicate, _IndexIfHeadMatches) ->
   assert(false, "Couldn't find list element that matched predicate."),
   {}
.

%===============================================================================

% Returns a tuple with three elements: a list of the dband records with z > Z,
% the dband record containing Z, and the dband records with z < Z.
% The lists are sorted by Z such that the element closest in z-value to Z is
% at the head of each list.
partition_dbands(DbandInfoList, Z1) ->
   Filter = (fun(X) -> 
      (X#dband_info.z_deep =< Z1) and (Z1 =< X#dband_info.z_shallow) end),
   InitialDbandIndex = get_index_of(DbandInfoList, Filter),
   
   {ShallowList, Remainder} = lists:split(InitialDbandIndex - 1, DbandInfoList),
   [DbandInfo | DeeperList] = Remainder,

   {ShallowList, DbandInfo, DeeperList}
.

%===============================================================================

debug_validate_dbands(ShallowerList, DbandInfo, DeeperList, Z) ->
   NotShallowerFilt = (fun(X) -> 
      (X#dband_info.z_deep < Z) end),

   NotDeeperFilt = (fun(X) -> 
      (X#dband_info.z_shallow > Z) end),

   ShallowErrors = lists:filter(NotShallowerFilt, ShallowerList),
   DeepErrors = lists:filter(NotDeeperFilt, DeeperList),

   assert(length(ShallowErrors) == 0, "Problem A"),
   assert(length(DeepErrors) == 0, "Problem B"),

   #dband_info{z_deep = Z_deep, z_shallow=Z_shallow} = DbandInfo,
   assert((Z_deep =< Z), "Problem C"),
   assert((Z_shallow >= Z), "Problem D")
.

%===============================================================================


% Returns a list of the boundary crossings of the ray as it propagates from
% range R1 to R_max or until it bounces NBounce_max times.  

% trace_one_ray(DbandInfoList, R1, Z1, Theta1, R_max, NBounce_max) ->
%    assert(cos(Theta1) > 0, "Theta1 mus have a cos > 0."),
%    assert(R1 < R_max, "Must be true that R1 < R_max"),

trace_one_ray(DbandInfoList, R1, Z1, Theta1, R_max, NBounce_max) ->
   % The first entry in the list should be the ray's very initial status.   
   InitialRayStatus = #ray_status{z=Z1, r=R1, theta=Theta1, num_bounces=0},
   BoundaryCrossingsList = [InitialRayStatus],

   {ShallowerList, DbandInfo, DeeperList} = partition_dbands(DbandInfoList, Z1),

   InitialIncidentBoundary = 
      if 
         Z1 =:= DbandInfo#dband_info.z_shallow -> shallow_z_boundary;
         Z1 =:= DbandInfo#dband_info.z_deep    -> deep_z_boundary;
         true                                  -> low_range_boundary
      end,

   { CompleteBoundaryList, _ } = trace_one_ray_helper(
         ShallowerList, DbandInfo, DeeperList, 
         R_max, NBounce_max, InitialIncidentBoundary,
         BoundaryCrossingsList),
   lists:reverse( CompleteBoundaryList )
.

%===============================================================================

% Traces the ray until its termination condition is met.  Returns 
% {BoundaryCrossingsList, LastExitBoundary}
%
% BoundaryCrossingsList is a list containing the input parameter list of the
% same name, prepended with all boundary crossings that occur after
% (not including) the initial condition of the ray.
%
% LastExitBoundary describes the boundary from which the ray exited the last
% cell added to the list; that cell is at the head of the list.  This will
% be one of the atoms: shallow_z_boundary, deep_z_boundary, high_range_boundary.
trace_one_ray_helper(
      ShallowerList, DbandInfo, DeeperList,
      R_max,                % Maximum range to which we're tracing rays.
      NBounce_max,          % Max. number of bounces before terminating a ray 
                            % trace.
      IncidentBoundary,     % atom saying which boundary of the rectangular cell
                            % the ray is initially at.
      BoundaryCrossings % List of boundary crossings the ray has undergone
                            % so far.
      ) ->
   % The head of BoundaryCrossings gives the most recent status of the ray, and
   % is the state from which this function call must extend the ray.
   [#ray_status{z=Z1, r=R1, theta=Theta1, num_bounces=NumBounces} | _ ] = BoundaryCrossings,

% debug_validate_dbands(ShallowerList, DbandInfo, DeeperList, Z1),


   if ((R1 =:= R_max) or (NumBounces =:= NBounce_max)) ->
      % The ray has met a terminal condition, so no further tracing is 
      % needed.
      {BoundaryCrossings, IncidentBoundary}
   ; true -> 
      % The ray didn't meet any terminal criteria, so advance it...
      #dband_info{z_deep = Z_deep, z_shallow=Z_shallow, 
         c_z_deep=C_z_deep, c_z_shallow=C_z_shallow} 
         = DbandInfo,

      {New_R, New_Z, New_Theta, New_boundary} = advance_ray_through_dband(
         R1, Z1, Theta1, IncidentBoundary, 
         Z_shallow, Z_deep, C_z_shallow, C_z_deep, R_max),
   
      case New_boundary of high_range_boundary ->
         % The high range boundary means that the ray reached R_max, so
         % there's no need to further trace the ray.
         NewRayStatus = #ray_status{z=New_Z, r=New_R, 
            theta=New_Theta, num_bounces=NumBounces},

         {[NewRayStatus | BoundaryCrossings], IncidentBoundary}
      ; shallow_z_boundary ->
         % We need to handle reflection off the surface if it occurred...
         if (length(ShallowerList) =:= 0) ->
            % The ray just hit the surface, so its a reflection...
            NewRayStatus = #ray_status{z=New_Z, r=New_R, 
               theta=(New_Theta * -1), num_bounces=(NumBounces + 1)},
            
            trace_one_ray_helper(
                  ShallowerList, DbandInfo, DeeperList, R_max, NBounce_max, 
                  shallow_z_boundary, 
                  [NewRayStatus | BoundaryCrossings])
         ; true ->
            % Simple propagation...
            NewRayStatus = #ray_status{z=New_Z, r=New_R, 
               theta=New_Theta, num_bounces=NumBounces},
            
            % Exiting via a shallow boundary, when there's no 
            % reflection implies entering the new depth band via its
            % deep boundary.
            [ NewDbandInfo | NewShallowerList ] = ShallowerList,
            NewDeeperList = [ DbandInfo | DeeperList ],
            trace_one_ray_helper(
                  NewShallowerList, NewDbandInfo, NewDeeperList, R_max, NBounce_max, 
                  deep_z_boundary,
                  [NewRayStatus | BoundaryCrossings])
         end
      ; deep_z_boundary ->
         if (length(DeeperList) =:= 0) ->
            % The ray just hit the ocean floor, so its a reflection...
            NewRayStatus = #ray_status{z=New_Z, r=New_R, 
               theta=(New_Theta * -1), num_bounces=(NumBounces + 1)},
            
            trace_one_ray_helper(
                  ShallowerList, DbandInfo, DeeperList, R_max, NBounce_max, 
                  deep_z_boundary, 
                  [NewRayStatus | BoundaryCrossings])
         ; true ->
            % Simple propagation...
            NewRayStatus = #ray_status{z=New_Z, r=New_R, 
               theta=New_Theta, num_bounces=NumBounces},
            
            % Exiting via a deep boundary, when there's no 
            % reflection implies entering the new depth band via its
            % shallow boundary.
            [ NewDbandInfo | NewDeeperList ] = DeeperList,
            NewShallowerList = [ DbandInfo | ShallowerList ],

            trace_one_ray_helper(
                  NewShallowerList, NewDbandInfo, NewDeeperList, R_max, NBounce_max, 
                  shallow_z_boundary, 
                  [NewRayStatus | BoundaryCrossings])
         end % if
      end % case
   end %if
.

%===============================================================================

% Traces the subset of rays in the specified range that correspond to the 
% Offset hash-offset.
%
% Returns the set of ray traces as a list with one entry per ray.
trace_hashed_rays(DbandInfoList, R1, Z1, R_max, NBounce_max, LowDE_Rad, 
      HighDE_Rad, NumRays, NumBuckets, Offset) ->

   DeRadiansList = partition_range_with_hash(
      LowDE_Rad, HighDE_Rad, NumRays, NumBuckets, Offset),

   TraceFun = fun(DE) -> ray_trace:trace_one_ray(
      DbandInfoList, R1, Z1, DE, R_max, NBounce_max) 
      end,

   % For now we're going to throw out the results of the tracing.  It's 
   % sufficient for our benchmarking purposes to have gathered the the results.
   lists:map(TraceFun, DeRadiansList),

   erlang:garbage_collect()
.

%===============================================================================

% Traces a bunch of rays.
%
% Returns the number of wall-clock seconds required to trace the rays and receive the 
% results.  This measurement does *not* include the time needed to process the 
% SSP file.
trace_many_rays(LowDE, HighDE, NumRays, NumProcs) ->
   Ssp = dband:load_ssp("andrew1.ssp"),
   DbandInfoList = dband:ssp_to_dband_info_list(Ssp),

   statistics(wall_clock),

   LowDE_Rad = LowDE * (math:pi() / 180),
   HighDE_Rad = HighDE * (math:pi() / 180),

   R1 = 0,
   Z1 = 1849,
   R_max = 10000,
   NBounce_max = 50,

   TraceFun = fun(HashOffset) -> trace_hashed_rays(
      DbandInfoList, R1, Z1, R_max, NBounce_max, LowDE_Rad, HighDE_Rad, 
      NumRays, NumProcs, HashOffset) end,

   HashOffsets = lists:seq(0, (NumProcs-1)),

   % For now we're going to throw out the results of the tracing.  It's 
   % sufficient for our benchmarking purposes to have gathered the the results.
   Traces = lib_misc:pmap1(TraceFun, HashOffsets),

   {_, Elapsed_ms} = statistics(wall_clock),
   {Traces, Elapsed_ms/1000}
.

%===============================================================================

% Traces a bunch of rays.
%
% Returns the number of wall-clock seconds required to trace the rays and receive the 
% results.  This measurement does *not* include the time needed to process the 
% SSP file.
trace_many_rays_singlethread(LowDE, HighDE, NumRays) ->
   Ssp = dband:load_ssp("andrew1.ssp"),
   DbandInfoList = dband:ssp_to_dband_info_list(Ssp),

   statistics(wall_clock),

   LowDE_Rad = LowDE * (math:pi() / 180),
   HighDE_Rad = HighDE * (math:pi() / 180),

   R1 = 0,
   Z1 = 1849,
   R_max = 10000,
   NBounce_max = 50,

   trace_hashed_rays(
      DbandInfoList, R1, Z1, R_max, NBounce_max, LowDE_Rad, HighDE_Rad, 
      NumRays, 1, 0),

   {_, Elapsed_ms} = statistics(wall_clock),
   Elapsed_ms/1000
.

%===============================================================================
% 
% trace_hashed_rays_smp_rpc(
%       DbandInfoList, R1, Z1, R_max, NBounce_max, LowDE_Rad, 
%       HighDE_Rad, NumRays, NumBuckets, Offset) ->
% 
% 
% 
% trace_hashed_rays(DbandInfoList, R1, Z1, R_max, NBounce_max, LowDE_Rad, 
%       HighDE_Rad, NumRays, NumBuckets, Offset) ->
% 

%===============================================================================

partition_range_with_hash(Low, High, NumItems, NumBuckets, Offset) ->
   assert(Low =< High, "Must have Low <= High"),
   assert(0 =< Offset, "Must have 0 =< Offset"),
   assert(Offset < NumBuckets, "Must have Offset < NumBuckets"),

   PerItemDelta = (High - Low) / (NumItems-1),
   Delta = NumBuckets * PerItemDelta,
   NextToAdd = Low + (Offset * PerItemDelta),

   lists:reverse(partition_range_with_hash1(NextToAdd, High, Delta, []))
.

partition_range_with_hash1(NextToAdd, High, Delta, Acc) ->
%    io:format("A: NextToAdd=~p~n", [NextToAdd]),
   if (NextToAdd =< High) ->
      partition_range_with_hash1((NextToAdd + Delta), High, Delta, [NextToAdd | Acc])
   ; true ->
      Acc
   end
.
