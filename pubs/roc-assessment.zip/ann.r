## build a neural network model and construct performance metrics
## GNU GENERAL PUBLIC LICENSE 2006 - Lutz Hamel, University of Rhode Island

library(nnet)
library(ROCR)

########################## function definitions


## define functions that compute metrics on a confusion table

accuracy <- function(t) {
	if (is.table(t)) {
		# (TP+TN)/(TP+TN+FP+FN)
		(t[1] + t[4])/(t[1] + t[2] + t[3] + t[4])
	} else {
		print("not a table")
	}
}

precision <- function(t) {
	if (is.table(t)) {
		# TP/(TP+FP)
		t[4]/(t[2] + t[4])
	} else {
		print("not a table")
	}
}

recall <- function(t) {
	if (is.table(t)) {
		# TP/(TP+FN)
		t[4]/(t[3] + t[4])
	} else {
		print("not a table")
	}
}

fpr <- function(t) {
	if (is.table(t)) {
		# FP/(TN+FP)
		t[2]/(t[1] + t[2])
	} else {
		print("not a table")
	}
}

## function to construct a confusion matrix and its derived metrics

confusion.table <- function(data = NULL,model = NULL) {
	pred <- predict(model, data[,-1],type = "class")
	confusion <- table(pred,data$Class)
	print(confusion)
	cat("accuracy: ",accuracy(confusion),"\n")
	cat("precision: ",precision(confusion),"\n")
	cat("tpr/recall: ",recall(confusion),"\n")
	cat("fpr: ",fpr(confusion),"\n")
}

## build ROC curve

roc.curve <- function (data = NULL,
					   model = NULL,
					   add = FALSE, 		# add to existing graph
					   colorize = FALSE,	# annotate with threshold info
					   lines = TRUE			# add orientation lines to graph
					   ) {
	pred.raw <- predict(model, data[,-1],type = "raw")
	roc.pred <- prediction(pred.raw,data$Class)
	roc.perf <- performance(roc.pred,"tpr","fpr")
	plot(roc.perf,colorize=colorize,add=add)
	# orientation lines
	if (lines) {
		lines(c(0,1),c(0,1),lty="dashed")
		lines(c(0,.5),c(1,.5),lty="dashed")
	}
}

## build precision-recall curve

prec.rec.curve <- function(data = NULL,
						   model = NULL,
						   add = FALSE		# add to existing graph
						   ) {
	pred.raw <- predict(model, data[,-1],type = "raw")
	roc.pred <- prediction(pred.raw,data$Class)
	roc.perf <- performance(roc.pred,"prec","rec")
	plot(roc.perf,xlim=c(0,1.0),ylim=c(0,1.0),add=add)
}

##################### computation

## load the data
d <- read.csv("ringnorm1.csv", sep=",")
d.skew <- read.csv("ringnorm-skew1.csv", sep=",")

## build the model
net.model <- nnet(Class ~ ., data = d, size = 1, rang = 0.1, decay = 5e-4, maxit = 50)

## build the confusion matrix

confusion.table(d,net.model)									# normal data
confusion.table(d.skew,net.model)								# skewed data

## build the ROC curves

quartz()
roc.curve(data=d,model=net.model,colorize=TRUE) 				# normal data with threshold values
quartz()
roc.curve(data=d,model=net.model)								# normal data
roc.curve(data=d.skew,model=net.model,add=TRUE,lines=FALSE) 	# skewed data

## build the prec-recall curve

quartz()
prec.rec.curve(data=d,model=net.model)							# normal data
prec.rec.curve(data=d.skew,model=net.model,add=TRUE)			# skewed data



