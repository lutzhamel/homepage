Data due to:

Breiman L.  Bias, variance and arcing
classifiers. Tec. Report 460, Statistics
department. University of california. April
1996. 
