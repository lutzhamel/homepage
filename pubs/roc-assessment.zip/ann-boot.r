## build a neural network model with ROC curves & confidence interval bands
## use the bootstrap to compute the confidence interval of a ROC curve
## GNU GENERAL PUBLIC LICENSE 2006 - Lutz Hamel, University of Rhode Island

library(nnet)
library(ROCR)


###### function definitions
load.data <- function () {
	## load the data and sample down
	data.orig <- read.csv("ringnorm.csv", sep=",")
	# randomize the data rows
	sample.template <- 1:length(data.orig$Class) 
	ix.vec <- sample(sample.template,replace=FALSE)
	data.rand <- data.orig[ix.vec,]
	# sample down
	sample.template <- 1:1000
	ix.vec <- sample(sample.template,replace=FALSE)
	data.rand[ix.vec,]
}


build.plot.nnet <- function(
					data = NULL,
					plot.add = TRUE,
					net.size = 3,
					net.iter = 50,
					net.trace = FALSE
					) {
	# lists holding the results for our bootstrap samples
	predictions <- list()
	labels <- list()
	return.val <- list()
	
	sample.template <- 1:length(data$Class) 
	no.of.samples <- 50

	## compute predictions on bootrap samples
	for (i in 1:no.of.samples) {
		#cat("building ",i,"\n")
		ix.vec <- sample(sample.template,replace=TRUE)
		boot.data <- data[ix.vec,]
		net.model <- nnet(Class ~ ., data = boot.data, size = net.size, rang = 0.1, decay = 5e-4, maxit = net.iter,trace=net.trace)
		net.pred <- predict(net.model, boot.data[,-1],type = "raw")
		predictions[[i]] <- net.pred
		labels[[i]] <- boot.data$Class
	}

	## build the ROC curves
	roc.pred <- prediction(predictions,labels)
	roc.perf <- performance(roc.pred,"tpr","fpr")
	#plot(roc.perf, main = "ROC: bootstrap")
	plot(roc.perf, avg = "vertical", spread.estimate = "stddev",spread.scale=2,add=plot.add)
       
	# orientation lines
	lines(c(0,1),c(0,1),lty="dashed")
	#lines(c(0,.5),c(1,.5),lty="dashed")

	# the function returns a list that contains a list of the bootstrap predictions and a list
	# of the bootstrap labels
	return.val[[1]] <- predictions
	return.val[[2]] <- labels
	return.val
}

###### start our actual computation

d <- load.data()

quartz()
build.plot.nnet(data=d,plot.add=FALSE,net.size=1,net.iter=50)
build.plot.nnet(data=d,plot.add=TRUE,net.size=3,net.iter=100)

quartz()
build.plot.nnet(data=d,plot.add=FALSE,net.size=1,net.iter=50)
build.plot.nnet(data=d,plot.add=TRUE,net.size=10,net.iter=100)

